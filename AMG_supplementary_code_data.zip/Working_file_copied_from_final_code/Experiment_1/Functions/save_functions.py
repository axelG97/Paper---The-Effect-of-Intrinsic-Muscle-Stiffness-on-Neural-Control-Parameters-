from general_functions import *
from muscle_functions import *
from constants_functions import *
import xarray as xr
def save_huxley(l_mtcs,tot_bridge_nr,states,STIM,calculated_muscle_forces,mtc_vels,lCEs,lSEs,K_SE_list,t_vals,save_name,specific_save_name=False,saveornot=True):
    '''
    state_names = [[]]*(tot_bridge_nr*2+2)
    for i in range(tot_bridge_nr):
        state_names[i]='x'+str(i)
        state_names[i+tot_bridge_nr]='n'+str(i+tot_bridge_nr)
    state_names[-2]='lce'
    state_names[-1]='activation'
    '''
    huxley_data_full = xr.Dataset(
        data_vars=dict(
            #states=(['time','bridge_variable'], states),
            Fce_mtc=(['time'],calculated_muscle_forces[:,0]),
            Fse_mtc=(['time'],calculated_muscle_forces[:,1]),
            F_mtc=(['time'],calculated_muscle_forces[:,2]),
            v_mtc=(['time'],mtc_vels),
            l_mtc=(['time'],l_mtcs),
            STIM=(['time'],STIM),
            lCE=(['time'],lCEs),
            lSE=(['time'],lSEs),
            #lmtc=(['mtc_nr','time'],coords_vals[:,2,:]),
            KSE=(['time'],K_SE_list),
            #KCE=(['mtc_nr','time'],K_CE_list),
            #coord=(['time','coord_type','coord_nr'],coords_vals[:,:,1:]),
            #angle_values=(['time','s_item'],s_vals)
            #alleen nog s 
        ),
        coords=dict(
            #muscle=(["1", "2","3", "4","5", "6"], range(muscle_number)),
            #muscle=(['mtc_nr'], [1,2,3,4,5,6]),

            time=(t_vals)#,
            #coord_type=(['x','y','lmtc']),
            #coord_nr=(range(5)),
            #s_item=(['a1','a2','a3','a1d','a2d','a3d',])

        ),
        attrs=dict(description="States over time"),
    )
    #df_3d = states_set.to_dataframe()
    #print(df_3d)
    #import time
    print(huxley_data_full)
    if specific_save_name != False:
        huxley_data_full.to_netcdf('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_1/Results/data/'+str(save_name)+'__'+str(specific_save_name))
    if specific_save_name == False:
        huxley_data_full.to_netcdf('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_1/Results/data/'+str(save_name)+'huxley_data_full_'+time.ctime())

    #testdata = xarray.open_dataset('Results/data/data_full_Sun Nov 27 22:43:30 2022_')
    #testdata.time()
    return 'data saved succesfully.'

def save_hill(l_mtcs,calculated_muscle_forces,force_vector,v_mtcs,STIM,lCEs,vCEs,t_vals,save_name,specific_save_name=False,saveornot=True):
    #[F_hill_total,F_CE,F_SE,F_PE,FL,vmax,FV,vce,f_rel]
    hill_data_full = xr.Dataset(
        data_vars=dict(
            F_mtc=(['time'],calculated_muscle_forces),
            v_mtc=(['time'],v_mtcs),
            l_mtc=(['time'],l_mtcs),
            STIM=(['time'],STIM),
            lCE=(['time'],lCEs),
            vCE=(['time'],vCEs),
            F_CE=(['time'],force_vector[:,1]),
            F_SE=(['time'],force_vector[:,2]),
            F_PE=(['time'],force_vector[:,3]),
            FL=(['time'],force_vector[:,4]),
            vmax=(['time'],force_vector[:,5]),
            FV=(['time'],force_vector[:,6]),
            vce=(['time'],force_vector[:,7]),
            f_rel=(['time'],force_vector[:,8]),
        ),
        coords=dict(
            time=(t_vals)#
        ),
        attrs=dict(description="States over time"),
    )
    print(hill_data_full)
    if specific_save_name != False:
        hill_data_full.to_netcdf('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_1/Results/data/'+str(save_name)+'__'+str(specific_save_name))
    if specific_save_name == False:
        hill_data_full.to_netcdf('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_1/Results/data/'+str(save_name)+'hill_data_full_'+time.ctime())

    #testdata = xarray.open_dataset('Results/data/data_full_Sun Nov 27 22:43:30 2022_')
    #testdata.time()
    return 'data saved succesfully.'