from general_functions import *
from muscle_functions import *

# from matrices_functions import *


def muscle_vals_func(): 
    # define more constants
    (
        C1,
        C2,
        Fmax,
        lCEopt,
        s_mtc,
        K_SE,
        K_PE,
        K_CE,
        F_CEopt,
        width,
        t_act,
        t_deact,
        l_seslack,
        l_peslack,
        o_a_SE,
        o_a_PE,
        o_b_SE,
        o_b_PE,
        l_min,
        l_max,
        h_mtc_og,
    ) = sm.symbols(
        "C_1, C_2, F_max, l_(CE_(opt)), s_mtc, K_SE, K_PE, K_CE, F_(CE_(opt)), width, t_act, t_deact, l_(se_(slack)), l_(pe_(slack)), o_(a_(SE)), o_(a_(PE)), o_(b_(SE)), o_(b_(PE)), l_(min), l_(max),h_mtc_og"
    )
    h_mtc, f1, g1, g2, g3 = sm.symbols("h_mtc, f_1, g_1, g_2, g_3")
    l_r, l_t, L_opt, L_sh, V_er, V_ml, V_vm, V_sh, V_shl = sm.symbols(
        "l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl"
    )  # Stroeve hill extra constants
    SE_sh, PE_sh, SE_Ftoe, SE_xm, PE_xm, A, epstoe, klin = sm.symbols(
        "SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin"
    )  # thelen stiffness extra constants
    """
    h_mtc: 1,#1E-8,
    f1: 80,      
    g1: 10,      
    g2: 350,  
    g3: 160, 
    """
    muscle_pars_1 = {
        h_mtc: 1,  # 2.8418E-008,
        f1: 275.8722,
        g1: 176.6001,
        g2: 1065.6713,
        g3: 305.0962,
        C1: 1,  # arbitrary
        C2: 1,  # arbitrary
        Fmax: 1,  # arbitrary
        lCEopt: 0.1,
        s_mtc: 2.6e-6,
        K_SE: 1,  # arbitrary
        K_PE: 1,  # arbitrary
        K_CE: 1,  # arbitrary
        F_CEopt: 1,
        width: 0,  # 0.56,
        t_act: 40,  # ms
        t_deact: 70,  # ms
        l_seslack: 0.2,  # *l_ceopt,
        l_peslack: 1 / (1.05),  # *l_ceopt,
        o_a_SE: 0.04,
        o_a_PE: 0.1,
        o_b_SE: 0.5,
        o_b_PE: 0.6,
        l_r: 4,  # 0.15, #muscle rest length (m)
        l_t: 1,  # 0.02, #tendon length (m)
        L_opt: 0.7,  #
        L_sh: 0.6,  #
        V_er: 0.5,  #
        V_ml: 1.3,  # 1.3, #
        V_vm: 6,  # *lce0, nog doen
        V_sh: 0.3,  # 0.3, #
        V_shl: 0.23,  #
        l_min: 0.3,  # 0.1, #minimum muscle length
        l_max: 0.5,  # 0.8, #maximum muscle length
        # Thelen stiffness parameters from here
        SE_sh: 3,
        PE_sh: 5,
        SE_Ftoe: 0.33,
        SE_xm: 0.06,
        PE_xm: 0.6,
        A: 0,
        epstoe: 0,
        klin: 0,
        h_mtc_og: 2.8418e-008,
    }

    mus_vals = []
    mus_vals.append(np.array(list(muscle_pars_1.values())))
    return mus_vals


def constant_altering_function(
    mus_vals,
    current_muscle_start_lengths,
    states,
    muscle_number,
    tot_bridge_nr,
    model_type,
    hill_type,
    Fmax_muscles=False,
    experiment_name=False,
    specific_save_name=False,
):
    if Fmax_muscles != False:
        mus_vals[7] = Fmax_muscles
    mus_vals[15] = (
        mus_vals[15] * 0.001
    )  # *steps_per_second #activation constants from ms to step
    mus_vals[16] = mus_vals[16] * 0.001  # *steps_per_second
    mus_vals[
        8
    ] = 0.28  # current_muscle_start_length
    if "full_curve_longestmuscle" in experiment_name:
        mus_vals[32] = 0.21789  # minimum muscle length
        mus_vals[33] = 0.42210  # maximum muscle length
        if "stiff_start_neg" in specific_save_name:
            mus_vals[8] = 0.28
        if "stiff_start_pos" in specific_save_name:
            mus_vals[8] = 0.29284
    if "full_curve_longmuscle" in experiment_name:
        mus_vals[32] = 0.21789  # minimum muscle length
        mus_vals[33] = 0.42210  # maximum muscle length
        if "stiff_start_mostpos" in specific_save_name:
            mus_vals[8] = 0.29284
        if "stiff_start_verypos" in specific_save_name:
            mus_vals[8] = 0.28
        if "stiff_start_newpos" in specific_save_name:
            mus_vals[8] = 0.26716
        if "stiff_start_newneg" in specific_save_name:
            mus_vals[8] = 0.25432
        if "stiff_start_mostneg" in specific_save_name:
            mus_vals[8] = 0.24148
        if "stiff_start_extraneg" in specific_save_name:
            mus_vals[8] = 0.22864
    if "full_curve_shortmuscle" in experiment_name:
        mus_vals[32] = 0.0814296  # minimum muscle length
        mus_vals[33] = 0.1756696  # maximum muscle length
        if "stiff_start_mostpos" in specific_save_name:
            mus_vals[8] = 0.13524
        if "stiff_start_verypos" in specific_save_name:
            mus_vals[8] = 0.12240
        if "stiff_start_newpos" in specific_save_name:
            mus_vals[8] = 0.10956
        if "stiff_start_newneg" in specific_save_name:
            mus_vals[8] = 0.09672
        if "stiff_start_mostneg" in specific_save_name:
            mus_vals[8] = 0.08388
        if "stiff_start_extraneg" in specific_save_name:
            mus_vals[8] = 0.07104
    mus_vals[14] *= current_muscle_start_lengths

    mus_vals[17] *= mus_vals[8]
    mus_vals[18] *= mus_vals[8]
    ffmax = mus_vals[7]
    mus_vals[19] *= current_muscle_start_lengths
    mus_vals[20] *= current_muscle_start_lengths
    mus_vals[21] *= current_muscle_start_lengths
    mus_vals[22] *= current_muscle_start_lengths
    mus_vals[24] *= mus_vals[17] * 1.07
    mus_vals[29] *= mus_vals[8]  # V_vm 0.28#
    mus_vals[39] = (
        mus_vals[36] * mus_vals[34] * np.exp(mus_vals[34])
        - mus_vals[36] * np.exp(mus_vals[34])
        + mus_vals[36]
        + np.exp(mus_vals[34])
        - 1
    )
    # A
    mus_vals[40] = (
        mus_vals[36] * mus_vals[34] * np.exp(mus_vals[34]) * mus_vals[37] / mus_vals[39]
    )
    # epstoe
    mus_vals[41] = mus_vals[39] / (mus_vals[37] * (np.exp(mus_vals[34]) - 1))
    # klin

    #set up model-specific variables
    if model_type == "hill":
        SE0 = SEforce2length(mus_vals[7], mus_vals)  # Force/4 in Vardy
        states[0][0] = current_muscle_start_lengths - SE0  # initial length

    if model_type == "huxley":
        states[0][0:tot_bridge_nr] = np.linspace(
            -mus_vals[0] * 15, mus_vals[0] * 4, tot_bridge_nr
        ) 
        if 'full_curve' in experiment_name:
            states[0][0:tot_bridge_nr] = np.linspace(
            -mus_vals[0] * 30, mus_vals[0] * 30, tot_bridge_nr
        ) 
        if 'repeated_smallstretch' in experiment_name:
            states[0][0:tot_bridge_nr] = np.linspace(
            -mus_vals[0] * 15, mus_vals[0] * 4, tot_bridge_nr
        ) 
        for j in range(tot_bridge_nr):
            states[0][j + tot_bridge_nr] = n0_calc(states[0][j], mus_vals)
        xx = states[0][:tot_bridge_nr]
        nlimited = states[0][tot_bridge_nr : tot_bridge_nr * 2]
        nlimited[xx > 4 * mus_vals[0]] = 0
        nlimited[xx < -2 * mus_vals[0]] = 0
        intx0n0 = np.trapz(xx * nlimited)
        SE0 = SEforce2length(ffmax, mus_vals)  # Force/4 in Vardy
        print(SE0)
        states[0][-2] = current_muscle_start_lengths - SE0  # initial length
        mus_vals[6] = mus_vals[7] / intx0n0 # Force/4 in Vardy

    return mus_vals, states
