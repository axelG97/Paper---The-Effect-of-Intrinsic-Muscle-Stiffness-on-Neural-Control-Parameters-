
from general_functions import * 
from scipy.integrate import odeint

#l_mtc,v_mtc,states_previous_step,states_previous_step2,calculated_muscle_forces_previous_step,t_counter,h_step,v_type,FL_type, mus_vals,STIM,tot_bridge_nr,xlim=False,nlim=True

def huxley(l_mtc,v_mtc,states_previous_step,t_counter,h_step, mus_vals,tot_bridge_nr,STIM,xlim=False,nlim=True,FL_type='FL_hill',v_type='v_old',states_previous_step2=0,calculated_muscle_forces_previous_step=0):#per individual cross bridge
#l_mtc,v_mtc,states_previous_step,calculated_muscle_forces_previous_step,t_counter,h_step,v_type,FL_type, mus_vals,STIM,tot_bridge_nr,xlim=False,nlim=True    
    ''' Calculate the huxley equation for a muscle to return the produced force at each timestep
    
    Parameters
    -----------------------------------------
    l_mtc : float
        muscle-tendon complex length [m]
    v_mtc : float
        mtc velocity [m/s]
    tot_bridge_nr: float
        number of cross-bridges in each muscle
    x : float
        length of a cross-bridge [m]
    n : float
        probability of the cross-bridge being attached [-]
    lce : float
        length of contractile element    
    STIM : float, in between [0,1] [-]
        level of muscle stimulation, modelled equal for all cross-bridges
    activation : float, in between [0,1] [-]
        level of muscle activation, based on stimulation
    states_previous_step : array, shape(tot_bridge_nr*2 + 2,)
        Previous states of the muscle in the order [x1...xi,n1...ni,lce,activation]
    calculated_muscle_forces_previous_step: float
        level of force in previous step, [N]
    t_counter : float
        current step [s]
    h_step : float
        stepsize [s]
    mus_vals : array, shape(23,)
        muscle constants
    xlim : Boolean
        Toggles hard limits of x, set at [-2*h_mtc,4*h_mtc]
    t_span : 2-tuple
        Start time and stop time [s]
        
    Returns
    -----------------------------------------
    Ftot : float
        Total level of force produced by the muscle [N]
    new_states : array, shape(tot_bridge_nr*2 + 2,)
        Newly calculated states of the muscle in the order [x1...xi,n1...ni,lce,activation]
    '''  
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals #recall contants
    tspan = [t_counter,t_counter+h_step]
    
    FL_previous_step = 0
    FLd = 0
    if v_type=='v_new':
        if FL_type=='FL_0':
            FL_previous_step = 1
        if FL_type=='FL_hill':
            FL_previous_step = FL_hill(states_previous_step[-2], mus_vals)
            FLd = (FL_previous_step-FL_hill(states_previous_step2[-2], mus_vals))/h_step
        if FL_type=='FL_huxley':
            FL_previous_step = -FL_huxley(states_previous_step[-2], mus_vals)
            FLd = (FL_previous_step-FL_huxley(states_previous_step2[-2], mus_vals))/h_step
    
    
    
    
    
    # solve for next step
    #z = odeint(state_differentials_huxley,states_previous_step,tspan,args=(v_mtc,mus_vals,tot_bridge_nr,STIM,l_mtc,calculated_muscle_forces_previous_step,FL_previous_step,FLd,v_type,)) #odeint solver 
    
    #forward euler
    f_tnyn = state_differentials_huxley(states_previous_step,tspan,v_mtc,mus_vals,tot_bridge_nr,STIM,l_mtc,calculated_muscle_forces_previous_step,FL_previous_step,FLd,v_type)
    #print(f_tnyn)
    yn0 = states_previous_step
    yn1 = yn0 + h_step*f_tnyn
    z = [yn0,yn1]
    
    
    
    #nd = (z[1][tot_bridge_nr:tot_bridge_nr*2] - states_previous_step[tot_bridge_nr:tot_bridge_nr*2])/h_step
    x_temp = z[1][:tot_bridge_nr]
    n_temp = z[1][tot_bridge_nr:tot_bridge_nr*2]
    
    if nlim == True:
        n_temp[x_temp>4*h_mtc] = 0
        n_temp[x_temp<-2*h_mtc] = 0
    if xlim == True:
        x_temp[x_temp> 4*h_mtc] =  4*h_mtc
        x_temp[x_temp<-2*h_mtc] = -2*h_mtc
    
    K_SE, K_PE = EE_Thelen(mus_vals,l_mtc - states_previous_step[-2],states_previous_step[-2],include_PE=True)    
    FL=1
    lce=z[1][-2]
    activation = z[1][-1]
    F_pre = np.trapz(x_temp*n_temp)
    
    if FL_type=='FL_0':
        FL = -1
    if FL_type=='FL_hill':
        FL = -FL_hill(z[1][-2], mus_vals)
    if FL_type=='FL_huxley':
        FL = FL_huxley(z[1][-2], mus_vals)
    
    F_PE = 0 #temporarily, to test winters
    K_CE = C2*np.trapz(x_temp[(x_temp<=4*h_mtc)&(x_temp>=-2*h_mtc)])#maybe dF/dl ~+ (fcb2-fcb1)/(xcb2-xcb1))
    lpe = lce
    F_CE = -1*FL*activation*C2*F_pre
    #F_PE, K_PE = EE_FK(mus_vals,states_previous_step[-2]*1.3,'PE')
    Ftot = F_CE + F_PE
    F_SE = SElength2force(l_mtc-lce,mus_vals)*FL
    F_PE = PElength2forceThelen(lpe,mus_vals)#F_PE_hill(lpe,mus_vals)#PElength2forceThelen(lpe,mus_vals)  #PElength2force(lpe,mus_vals)  
    new_states = z[1]
    return [F_CE, F_SE, Ftot], new_states,K_SE,K_CE#.tolist() #returns CE force and all variables for all crossbridges per timestep
    #f vector change

def state_differentials_huxley(y,t,vmtc,mus_vals,tot_bridge_nr,STIM,l_mtc,calculated_muscle_forces_previous_step,FL_previous_step,FLd,v_type):
    #input: y [x1..xi,n1..ni,lce]m with i = nr of bridges
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    
    #previous values
    a_prev = y[-1]
    lce = y[-2]
    x = np.array(y[:tot_bridge_nr])
    n = np.array(y[tot_bridge_nr:tot_bridge_nr*2])
    
    #differentials
    nd = np.subtract(f_(x,mus_vals), np.multiply(np.add(g_(x,mus_vals),f_(x,mus_vals)),n)).tolist() #can also make it loop
    dadt = act_calc(mus_vals,STIM,a_prev)
    if v_type == 'v_old': 
        lced = v_ce4(lce,l_mtc,x,vmtc,mus_vals,n)
    if v_type == 'v_new':
        lced = v_ce_expanded(lce,l_mtc,x,vmtc,mus_vals,n,calculated_muscle_forces_previous_step,FL_previous_step,FLd,dadt,a_prev)
    #print('lced: ',lced)
    xd = lced*s_mtc /(h_mtc_og*2*lCEopt) #dlce = 2*lCEopt*dx/s
    
    dydt = [xd]*tot_bridge_nr + nd + [lced] + [dadt]
    return np.array(dydt)
    #return dydt #returns the differentials of the state variables, to work in accordance with odeint function


def f_(x,mus_vals):
    #f(x), as described in Vardy
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    xlist = np.zeros_like(x)
    xlist[x<0] = 0
    xlist[(x>=0)&(x<=h_mtc)] = f1*(x[(x>=0)&(x<=h_mtc)]/h_mtc)
    xlist[x>h_mtc] = 0
    return xlist


def g_(x,mus_vals):
    #g(x), as described in Vardy
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    xlist = np.zeros_like(x)
    xlist[(x<0)&(x>-2*h_mtc)] = g2
    xlist[(x>=0)&(x<=h_mtc)] = g1*(x[(x>=0)&(x<=h_mtc)]/h_mtc)
    xlist[(x>h_mtc)&(x<4*h_mtc)] = g1*(x[(x>h_mtc)&(x<4*h_mtc)]/h_mtc) + g3*(x[(x>h_mtc)&(x<4*h_mtc)]/h_mtc-1) #can try this
    return xlist


def v_ce4(lce, l_mtc,x,v,mus_vals,n,xlim=False,nlim=True,EE='Thelen'): #function to calculate the velocity of the contractile element
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    
    '''
    K_SE = EE_FK(mus_vals,l_mtc-lce,'SE')[1] #MAYBE?
    K_PE = EE_FK(mus_vals,lce,'PE')[1]
    ''' 
    if EE=='Vardy':
        K_PE = EE_FK(mus_vals,lce,'PE')[1]
        K_SE = EE_FK(mus_vals,l_mtc-lce,'SE')[1] #MAYBE?
    if EE == 'Thelen':
        K_SE, K_PE = EE_Thelen(mus_vals,l_mtc - lce,lce,include_PE=True)
    
    if EE == 'Winters':    
        K_SE = EE_Winters(mus_vals,l_mtc - lce,lce,include_PE=True)
        K_PE = 0
        #K_SE = -WS311
    
    #K_SE, K_PE = EE_Thelen(mus_vals,l_mtc - lce,lce,include_PE=True)
    #print('Vardy: ',K_SEV,' Thelen: ,',K_SE)
    xlist = np.array(x)
    n_list = np.array(n)
    g = g_(xlist,mus_vals)
    f = f_(xlist,mus_vals)
    
    if nlim == True:  #set to permanent true for now #causes long calc times and bad results
        #n_list=n_list[(xlist<4*h_mtc)&(xlist>-2*h_mtc)] #causes errors
        n_list[xlist>4*h_mtc] = 0
        n_list[xlist<-2*h_mtc] = 0
    if xlim == True:   #set to permanent false for now
        xlist[xlist>4*h_mtc] =  4*h_mtc
        xlist[xlist<-2*h_mtc]= -2*h_mtc
        
    I_n = np.trapz(n_list)*s_mtc / (h_mtc_og*2*lCEopt)#np.trapz(n_list)*s_mtc / (2*lCEopt)
    '''
    I_f_calc = I_f_func4(xlist,mus_vals)
    I_f = np.trapz(I_f_calc)
    I_H_calc = I_H_func4(xlist,mus_vals)
    I_H = np.trapz(n_list*I_H_calc)
    vce = (v*K_SE-C2*(I_f+I_H))/(K_SE+K_PE+C2*I_n) #version 1
    
    '''
    #------------ new #takes much longer to calculate
    dndt = f - (f+g)*(n_list)
    dndt[xlist>4*h_mtc] = 0
    dndt[xlist<-2*h_mtc] = 0                                                  
    Ixdndt = np.trapz(dndt*xlist)
    vce = (v*K_SE-C2*Ixdndt)/(K_SE+K_PE+C2*I_n)
    #------------
    
    return vce

def v_ce_expanded(lce,l_mtc,x,v_mtc,mus_vals,n,calculated_muscle_forces_previous_step,FL,FLd,dadt,a_prev,xlim=False,nlim=True,EE='Thelen'):
    #a longer and more accurate CE velocity formula that includes activation
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    F_CE, F_PE, Ftot = calculated_muscle_forces_previous_step

    if EE=='Vardy':
        K_PE = EE_FK(mus_vals,lce,'PE')[1]
        K_SE = EE_FK(mus_vals,l_mtc-lce,'SE')[1] #MAYBE?
    if EE == 'Thelen':
        K_SE, K_PE = EE_Thelen(mus_vals,l_mtc - lce,lce,include_PE=True)
    
    if EE == 'Winters':    
        K_SE = EE_Winters(mus_vals,l_mtc - lce,lce,include_PE=True)
        K_PE = 0
        #K_SE = -WS311
    
    #K_SE, K_PE = EE_Thelen(mus_vals,l_mtc - lce,lce,include_PE=True)
    #print('Vardy: ',K_SEV,' Thelen: ,',K_SE)
    xlist = np.array(x)
    n_list = np.array(n)
    g = g_(xlist,mus_vals)
    f = f_(xlist,mus_vals)
    
    if nlim == True:  #set to permanent true for now #causes long calc times and bad results
        #n_list=n_list[(xlist<4*h_mtc)&(xlist>-2*h_mtc)] #causes errors
        n_list[xlist>4*h_mtc] = 0
        n_list[xlist<-2*h_mtc] = 0
    if xlim == True:   #set to permanent false for now
        xlist[xlist>4*h_mtc] =  4*h_mtc
        xlist[xlist<-2*h_mtc]= -2*h_mtc
    
    #I_x  = np.trapz(n_list*xlist)    
    dndt = f - (f+g)*(n_list)
    dndt[xlist>4*h_mtc] = 0
    dndt[xlist<-2*h_mtc] = 0                                                  
    I_x = np.trapz(dndt*xlist)
    I_n = np.trapz(n_list)*s_mtc / (h_mtc_og*2*lCEopt)#np.trapz(n_list)*s_mtc / (2*lCEopt)
    #I_f_calc = I_f_func4(xlist,mus_vals)
    I_f = np.trapz(xlist*f)
    #I_H_calc = I_H_func4(xlist,mus_vals)
    I_H = np.trapz(n_list*x*-(f+g))
    
    return (K_SE*v_mtc*lce**2*np.sqrt(lce**2-width**2)-FL*C2*(dadt*I_x+a_prev*(I_f+I_H))*lce*(lce**2-width**2))/((a_prev*C2*(FLd*I_x+FL*I_n)+K_PE)*lce*(lce**2-width**2)+(F_CE+F_PE)*width**2+K_SE*lce**3)

def I_H_func4(x,mus_vals): #I_H function, as described in Vardy
    x = np.array(x)
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    return x*-(f_(x,mus_vals)+g_(x,mus_vals))

def I_f_func4(x,mus_vals): #I_f function, as described in Vardy
    x = np.array(x)
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    return (x*f_(x,mus_vals)).tolist() #x*f(x)

def dndt_func(x,mus_vals): #I_f function, as described in Vardy
    x = np.array(x)
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    return (x*f_(x,mus_vals)).tolist() #x*f(x)




def n0_calc(x,mus_vals): #initial conditions of n
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    if x < 0:
        return 0
    if (x >= 0) and (x <= h_mtc):
        return f1/(f1+g1)
    if x > h_mtc:
        return 0


def act_calc(mus_vals,STIM,a_prev): #activation dynamics model, to include delay in muscle activation
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    c1 = t_act**-1 + t_deact**-1 #different than C1 and C2!
    c2 = t_deact**-1
    if STIM >= a_prev:
        return (STIM-a_prev)*(c1*STIM+c2)
    if STIM < a_prev:
        return (STIM-a_prev)*c2
        
def FL_huxley(lce, mus_vals): #this function manual implements the force-length relationship 
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    '''
    A = -1/width**2 
    B = -2*A
    C = A + 1
    return Fmax*(A*lce**2 + B*lce + C)
    '''
    return Fmax*((-1/width**2)*lce**2 + (-2*(-1/width**2))*lce + ((-1/width**2) + 1))        
        
        
#-------- stiffness equations from vardy

def EE_FK(mus_vals,o_EE,EE='SE'): #this function takes in the length of one of both elastic elements and returns the current force and stiffness, in accordance to Vardy (paper)
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    #define parameters per element
    if EE == 'SE':
        o_toe = o_b_SE
        o_xm = o_a_SE
    if EE == 'PE':
        o_toe = o_b_PE
        o_xm = o_a_PE
    #formulas using the specific parameters
    F_toe = Fmax*o_toe/(o_toe-2*o_xm)
    SH_toe = 1/(o_toe*(o_toe-2*o_xm))
    k_lin = 2/(o_toe-2*o_xm)
    if o_EE <= o_toe:
        F_EE = Fmax*SH_toe*o_EE**2
        K_EE = 2*Fmax*SH_toe*o_EE
    if o_EE > o_toe:
        F_EE = Fmax*(k_lin*(o_EE-o_toe)+F_toe)
        K_EE = Fmax*k_lin
    return F_EE, K_EE

#new stiffness equations---------------------------------
def EE_Thelen(mus_vals,lSE,lPE,include_PE=True):#stiffness from matlab
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    #SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm = special_variables #SE_Ftoe = SE_SE_Ftoe
    epsSE = (lSE - l_seslack)/l_seslack;
    epsPE = (lPE - l_peslack)/l_peslack;
    Kse = 'Dead'
    if epsSE<=epstoe:
        Kse = (1/l_seslack)*((SE_sh/epstoe)*Fmax*SE_Ftoe*np.exp(SE_sh*epsSE/epstoe)/(np.exp(SE_sh)-1))
    if epsSE>epstoe:                                  
        Kse = (1/l_seslack)*Fmax*klin
    if Kse == 'Dead':
        print('Kse error')
        exit()
    Kpe = 0                                   
    if include_PE==True:
        if epsPE>0:
            Kpe = (1/l_peslack)*Fmax*(PE_sh/PE_xm)*np.exp(PE_sh*epsPE/PE_xm)/(np.exp(PE_sh)-1); 
    return Kse, Kpe


    
    
def EE_Winters(mus_vals,lSE,lPE,include_PE=True):#stiffness from matlab
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    epsSE = (lSE - l_seslack)/l_seslack;#*h_mtc?
    Kse = (1/l_seslack)*(SE_sh/SE_xm)*(Fmax*np.exp(SE_sh*epsSE/SE_xm)/np.exp(SE_sh)-1)
    #print('Kse: ',Kse)
    return Kse
#----- end stiffness equations

def SEforce2length(Fse,mus_vals): #Thelen not winters
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    if Fse > Fmax*SE_Ftoe: 
        epsSE = (Fmax*klin*epstoe-Fmax*SE_Ftoe+Fse)/(Fmax*klin);
    if Fse <= Fmax*SE_Ftoe: 
        epsSE = np.log((Fse*np.exp(SE_sh)-Fse+Fmax*SE_Ftoe)/(Fmax*SE_Ftoe))*epstoe/SE_sh;
    lSE = epsSE*l_seslack + l_seslack;
    return lSE

def SElength2force(lSE,mus_vals,EE='Thelen'):
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    epsSE = (lSE - l_seslack)/l_seslack;
    if EE == 'Thelen':         
        if epsSE<=epstoe: 
            Fse     = Fmax*SE_Ftoe*(np.exp(SE_sh*epsSE/epstoe)-1)/(np.exp(SE_sh)-1)
        if epsSE>epstoe: 
            Fse     = Fmax*(SE_Ftoe+ klin*(epsSE-epstoe))
    if EE == 'Winters':
        Fse     = Fmax*(np.exp(SE_sh*epsSE/SE_xm)-1)/(np.exp(SE_sh)-1);
    return Fse

def PElength2force(lPE,mus_vals):
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    epsPE = (lPE - l_peslack)/l_peslack;
    if epsPE<=0:
        Fpe=0
    if epsPE>0: 
        Fpe     = Fmax*(np.exp(PE_sh*epsPE/PE_xm)-1)/(np.exp(PE_sh)-1)
        #Fpe     = Fmax*(epsPE>0).*(exp(PE_sh*epsPE/PE_xm)-1)/(exp(PE_sh)-1)
    return Fpe
    
def PElength2forceThelen(lPE,mus_vals):
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    #eps0 = epsPE???? xm???passive muscle strain due to maximum isometric force, 0.6 young 0.5 old. Must be the PE_xm
    #L_M is the normalized muscle fiber length
    L_M = lPE / lCEopt
    
    Fpe = Fmax*(np.exp(PE_sh*(L_M-1)/PE_xm)-1)/(np.exp(PE_sh)-1)
    
    #F_PE = (1/(np.exp(PE_sh-1)))*np.exp(PE_sh*lse/PE_xm-1)
    return Fpe    









#from here: formulas are derived from the STroeve model
#file:///C:/Users/axelg.AXELS-LAPTOP/Documents/Stroeve(1999)%20Analysis%20of%20the%20Role%20of%20Proprioceptive%20Information%20During%20Arm%20Movemnet%20Using%20a%20Model%20of%20the%20Human%20Arm.pdf
#------
def hill(l_mtc,v_mtc,states_previous_step,force_vector_previous_step,t_counter,h_step, mus_vals,STIM,hill_type,FV_type='FV_hill',a_func=True):
    #state vector: [act]]
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    
    lce_prev,a_prev = states_previous_step
    tspan = [t_counter,t_counter+h_step]
    # solve for next step
    if hill_type == 'stroeve':
        vce_temp = v_mtc
        lce_prev = l_mtc - l_t
    if hill_type == 'thijs':
        #lce_prev = lce_prev #- 0.2
        lse_prev = l_mtc - lce_prev 
        F_CE_prev = force_vector_previous_step[1]
        F_SE_prev = force_vector_previous_step[2]#this one causes crazy high force if SE_xm: 0.04,l_t
        F_PE_prev = force_vector_previous_step[3]
        vmax_prev = force_vector_previous_step[5]
        FL_prev = force_vector_previous_step[4]
        vce_temp = v_ce_hill(a_prev,FL_prev,F_SE_prev-F_PE_prev,vmax_prev,mus_vals,v_mtc,h_step)#v_mtc#vCEhux#v_mtc#
    #z = odeint(state_differentials_hill,states_previous_step,tspan,args=(mus_vals,STIM,vce_temp,)) #odeint solver 
    #forward euler
    f_tnyn = state_differentials_hill(states_previous_step,tspan,mus_vals,STIM,vce_temp)
    #print(f_tnyn)
    yn0 = states_previous_step
    yn1 = yn0 + h_step*f_tnyn
    z = [yn0,yn1]
    new_states = z[1]
    if a_func == True:
        activation = new_states[1]
    if a_func == False:
        activation = STIM
    lce = lce_prev
    if hill_type == 'thijs':
        lce = new_states[0]    
    vce=vce_temp#*h_step#(lce-states_previous_step[0])/h_step
    FL  = FL_hill(lce,mus_vals)
    vmax = vmax_hill(activation,lce,FL,mus_vals)
    if FV_type == 'FV_hill':
        FV = FV_hill(vce,mus_vals,vmax)#FV_hill(vce,mus_vals,vmax)#correct is using vce
    if FV_type == 'FV_0':
        FV = 1
    if hill_type == 'stroeve':
        F_hill_total = FL*FV*activation*Fmax
        F_CE = F_hill_total
        F_SE,F_PE,vmax,vce,f_rel = 0,0,0,0,0
    if hill_type == 'thijs':
        F_CE = FL*FV*activation*Fmax
        F_SE = F_SE_hill(l_mtc-lce,mus_vals)
        F_PE = PElength2forceThelen(lce,mus_vals)#F_PE_hill(lce,mus_vals)#l_mtc,mus_vals)#maybe lse rather than lce
        F_hill_total = F_CE + F_PE
        f_rel = activation*F_SE_prev/(Fmax*FL_prev)#F_SE_prev/(Fmax*activation*FL_prev)
    return [F_hill_total,F_CE,F_SE,F_PE,FL,vmax,FV,vce,f_rel], new_states
 
def state_differentials_hill(y,t,mus_vals,STIM,vce):
    #input: y [x1..xi,n1..ni,lce]m with i = nr of bridges
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    
    #previous values
    lce_prev = y[0]
    a_prev = y[1]
    
    #differentials
    act = act_calc(mus_vals,STIM,a_prev)
    
    dydt = [vce]+[act]
    return np.array(dydt) #returns the differentials of the state variables, to work in accordance with odeint function

def F_PE_hill(lpe,mus_vals):
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    F_PE = Fmax*(1/(np.exp(PE_sh-1)))*np.exp(PE_sh*lpe/PE_xm-1)
    return F_PE

def F_SE_hill(lse,mus_vals):
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    lses = lse*0.056/l_seslack#2.333#
    F_SE = (1/(np.exp(SE_sh-1)))*np.exp(SE_sh*lses/SE_xm-1)
    #F_SE = (1/(np.exp(SE_sh-1)))*np.exp(SE_sh*lse/SE_xm-1)
    return F_SE

def v_ce_hill(act,FL,F_SE,vmax,mus_vals,v_mtc,h_step):
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    
    #if act < 0.1:
    #    act = 0.1
    if FL < 0.000000001:
        FL = 0.000000001
    f_rel = act*F_SE/(Fmax*1*FL)#thijs#act*F_SE/(Fmax*1*FL)
    ##f_rel = np.abs(f_rel)#to allow for negative veloctiy
    #print(F_SE,act,FL)
    if act == 0:#avoiding dividing by 0
        f_rel = 1
    if (f_rel>=0) and (f_rel<=1):
        vce=V_sh*vmax*(f_rel-1)/(f_rel+V_sh)#V_sh*vmax*(f_rel-1)/(f_rel+V_sh)
    if (f_rel>1) and (f_rel<=V_ml):
        vce=-V_sh*V_shl*vmax*(f_rel-1)/(f_rel+(-1-(1+V_sh*V_shl)*(V_ml-1)))#-V_sh*V_shl*vmax*(f_rel-1)/(f_rel+(-1-(1+V_sh*V_shl)*(V_ml-1)))
    if f_rel < 0:
        #print('Error: f_rel < 0')
        vce = v_mtc#-V_sh*vmax*(f_rel-1)/(f_rel+V_sh)
    if f_rel > V_ml:
        #print('Error: f_rel > V_ml')
        vce =v_mtc#V_sh*V_shl*vmax*(f_rel-1)/(f_rel+(-1-(1+V_sh*V_shl)*(V_ml-1)))#vmax
        #vce = vmax*h_step#V_ml*h_step
    #if v_mtc < 0:
    #    vce *= -1
    return vce#maybe no minus sign?

              
def FL_hill(lce,mus_vals):
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    lce_0 = l_min + L_opt*(l_max - l_min) - l_t
    lce_sh = L_sh*(l_max - l_min)
    #F_lce = np.exp(-1*((lce-lce_0)/lce_sh)**2)
    F_lce = np.exp(-1*((lce-lCEopt)/lce_sh)**2)#using the lCEopt from vardy definition
    return F_lce

def vmax_hill(act,lce,FL,mus_vals):
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    vmax = V_vm*(1-V_er*(1-act*FL))
    return vmax

def FV_hill(vce,mus_vals,vmax):
    h_mtc,f1,g1,g2,g3,C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE,l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl, l_min, l_max, SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin,h_mtc_og = mus_vals
    if vce <= -vmax: #maybe something wrong with -
        return 0
    if (vce > -vmax) and (vce <= 0):
        return V_sh*(vmax+vce)/(V_sh*vmax - vce)
    if vce > 0:
        return (V_sh*V_shl*vmax+V_ml*vce)/(V_sh*V_shl*vmax + vce)




def reflex_feedback(l_mtc,v_mtc,l_mtc_target,v_mtc_target,feedback_vector,current_STIM):
    #input: muscle length, muscle velocity, target muscle length, muscle feedback parameters
    #output: STIM level
    
    #draft of feedback system
    #delta_STIM = spA * delta_l / (spC) + spC
    #delta_l = l_target-l_mtc
    #delta_STIM = spA * (delta_l / l_target) ** spB
    
    #v2
    # spA, spB, spC = feedback_vector
    # delta_l = l_mtc-l_mtc_target
    # if delta_l >= 0:
    #     delta_STIM = spA * delta_l + spC
    # if delta_l < 0:
    #     delta_STIM = spB * delta_l + spC
     
    #v3
    # spA, spB, spC = feedback_vector    
    # delta_l = l_mtc-l_mtc_target    
    # delta_STIM = spA * delta_l + spB*v_mtc + spC*current_STIM    
        
    #v4    
    # spA, spB, spC,spD = feedback_vector    
    # delta_l = l_mtc-l_mtc_target    
    # #delta_STIM = spA * delta_l + spB*v_mtc + spC*current_STIM       
    # if delta_l >= 0:
    #     delta_STIM = spA * delta_l + spD*v_mtc + spC
    # if delta_l < 0:
    #     delta_STIM = spB * delta_l + spD*v_mtc + spC     
        
    #v5    
    # spA, spB, spC,spD = feedback_vector    
    # delta_l = l_mtc-l_mtc_target    
    # delta_v = v_mtc-v_mtc_target    
    # #delta_STIM = spA * delta_l + spB*v_mtc + spC*current_STIM       
    # if delta_l >= 0:
    #     delta_STIM = spA * delta_l + spD*delta_v + spC*current_STIM
    # if delta_l < 0:
    #     delta_STIM = spB * delta_l + spD*delta_v + spC*current_STIM 
      
    #v6     
    spA, spB, spC,spD = feedback_vector    
    delta_l = l_mtc-l_mtc_target    
    delta_v = v_mtc-v_mtc_target    
    #delta_STIM = spA * delta_l + spB*v_mtc + spC*current_STIM       
    delta_STIM = spA * delta_l +spB*delta_v+ spC*current_STIM+spD
        
    adjusted_STIM = current_STIM + delta_STIM
    if adjusted_STIM >= 1:
        adjusted_STIM = 1
    if adjusted_STIM <= 0.05:
        adjusted_STIM = 0.05    
    return adjusted_STIM






