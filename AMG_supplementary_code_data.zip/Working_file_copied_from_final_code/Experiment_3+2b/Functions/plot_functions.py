from general_functions import * 
from muscle_functions import *
from matrices_functions import *

def plot_huxley_full(t_vals, s_vals, coords_vals,mtc_vels,calculated_huxley_force,states,activation,t0,tf,t_pertubation,h_step,muscle_number,tot_bridge_nr,step_nr,mus_vals,p,v_type,FL_type,f_type,K_SE_list,K_CE_list,lCEs,lSEs,save=True,save_name=False,specific_save_name=False,optimal_trajectories=False,optimal_muscle_lengths=False):
    #calculated_huxley_force = calculated_muscle_forces[:][:][2]
    #%%time
    #plt.rcParams["figure.figsize"] = (8, 6)
    muscle_color_list   =['salmon','turquoise','darkblue','lime','magenta','gold']
    br_list = [(0.1,0.0,1.0),(0.2,0.0,0.9),(0.3,0.0,0.8),(0.4,0.0,0.7),(0.5,0.0,0.6),(0.6,0.0,0.5),(0.7,0.0,0.4),(0.8,0.0,0.3),(0.9,0.0,0.2),(1.0,0.0,0.1)]#color = [(0.3,0.3,0.5)]

    #muscle_color_list_2 =['salmon','lime','slateblue']
   # if type(optimal_trajectories) == bool:
        #fig, axes = plt.subplots(5,6,figsize=(35,25))
    fig, axes = plt.subplots(6,6,figsize=(35,30))
    fig.suptitle(str(h_step)+' steps, '+str(v_type)+str(FL_type)+str(f_type)+'fmax1: '+str(mus_vals[0][7])+',thelen, m3: '+str(p[10])+', J3: '+str(p[11]))
    #fig.suptitle(str(p)+str(r)+str(muscle_pars_1)+'t0: '+str(t0)+', tf: '+str(tf)+', h: '+str(h_step))
    axes[0][0].grid(visible=True);
    for i in range(muscle_number):
        axes[0][0].plot(t_vals, activation[i],muscle_color_list[i])
    #for i in range(muscle_number):    
    #    axes[0][0].plot(t_vals, states[i][:,-1],muscle_color_list[i]);
    axes[0][0].set_title("Activation over time")#, Winters, "+ str(h_step)+' stepsize,old v,old f,FLhills,bigfmax, thelen'
    axes[0][0].set_ylabel('activation [-]')
    axes[0][0].set_xlabel("Time [s]");
    axes[0][0].legend(['MTC_1','MTC_2','MTC_3','MTC_4','MTC_5','MTC_6'])
    axes[1][0].grid(visible=True);
    # for i in range(tot_bridge_nr):
    #     axes[1][0].plot(t_vals, states[0][:,i]/mus_vals[0][0]);
    axes[1][0].set_title("x of all "+str(tot_bridge_nr)+" cross-bridges in mtc1")
    axes[1][0].set_ylabel('x [h]')
    axes[1][0].set_xlabel("Time [s]")
    axes[2][0].grid(visible=True);
    # for i in range(tot_bridge_nr):
    #     axes[2][0].plot(t_vals, states[0][:,i+tot_bridge_nr]);
    axes[2][0].set_title("n of all "+str(tot_bridge_nr)+" cross-bridges in mtc1")
    axes[2][0].set_ylabel('n')
    axes[2][0].set_xlabel("Time [s]")
    axes[2][0].set_ylim([0,1])
    axes[3][0].grid(visible=True);
    axes[3][0].plot(t_vals, states[0][:,-2]);
    axes[3][0].set_title("l_ce of all "+str(tot_bridge_nr)+" cross-bridges in mtc1")
    axes[3][0].set_ylabel('l [m]')
    axes[3][0].set_xlabel("Time [s]")
    '''
    axes[4][0].grid(visible=True);
    for i in range(tot_bridge_nr):
        axes[4][0].plot(states[0][:,i]/mus_vals[0][0], states[0][:,i+tot_bridge_nr]);
    axes[4][0].set_title("n(x) of all "+str(tot_bridge_nr)+" cross-bridges in mtc1")
    axes[4][0].set_ylabel('n [-]')
    axes[4][0].set_xlabel("x [h]")
    axes[4][0].set_ylim([0,1])
    '''
    axes[4][0].grid(visible=True);
    axes[4][0].plot(t_vals, lSEs[0]);
    axes[4][0].set_title("l_se of all "+str(tot_bridge_nr)+" cross-bridges in mtc1")
    axes[4][0].set_ylabel('l [m]')
    axes[4][0].set_xlabel("Time [s]")
    
    axes[0][1].grid(visible=True);
    for i in range(muscle_number):
        axes[0][1].plot(t_vals, calculated_huxley_force[i],muscle_color_list[i]);
    axes[0][1].set_ylabel('Muscle force [N]')
    axes[0][1].set_xlabel("Time [s]")
    axes[0][1].set_title("Muscle Forces")
    axes[0][1].legend(['MTC_1','MTC_2','MTC_3','MTC_4','MTC_5','MTC_6'])
    #states[0][:,0]
    axes[1][1].grid(visible=True);
    # for i in range(tot_bridge_nr):
    #     axes[1][1].plot(t_vals, states[1][:,i]/mus_vals[0][0]);
    axes[1][1].set_title("x of all "+str(tot_bridge_nr)+" cross-bridges in mtc2")
    axes[1][1].set_ylabel('x [h]')
    axes[1][1].set_xlabel("Time [s]")
    axes[2][1].grid(visible=True);
    # for i in range(tot_bridge_nr):
    #     axes[2][1].plot(t_vals, states[1][:,i+tot_bridge_nr]);
    axes[2][1].set_title("n of all "+str(tot_bridge_nr)+" cross-bridges in mtc2")
    axes[2][1].set_ylabel('n')
    axes[2][1].set_xlabel("Time [s]");
    axes[2][1].set_ylim([0,1])
    axes[3][1].grid(visible=True);
    axes[3][1].plot(t_vals, states[1][:,-2]);
    axes[3][1].set_title("l_ce of all "+str(tot_bridge_nr)+" cross-bridges in mtc2")
    axes[3][1].set_ylabel('l [m]')
    axes[3][1].set_xlabel("Time [s]")
    axes[4][1].grid(visible=True);
    axes[4][1].plot(t_vals, lSEs[1]);
    axes[4][1].set_title("l_se of all "+str(tot_bridge_nr)+" cross-bridges in mtc2")
    axes[4][1].set_ylabel('l [m]')
    axes[4][1].set_xlabel("Time [s]")
    axes[0][2].grid(visible=True);
    axes[0][2].plot(t_vals, coords_vals[:,0][:,1:]);
    axes[0][2].set_ylabel('x points [m]')
    axes[0][2].set_xlabel("Time [s]")
    axes[0][2].set_title("Structure movement in x-t")
    axes[0][2].legend(['x0','x1','x2','x3','x4'])
    axes[1][2].grid(visible=True);
    # for i in range(tot_bridge_nr):
    #     axes[1][2].plot(t_vals, states[2][:,i]/mus_vals[0][0]);
    axes[1][2].set_title("x of all "+str(tot_bridge_nr)+" cross-bridges in mtc3")
    axes[1][2].set_ylabel('x [h]')
    axes[1][2].set_xlabel("Time [s]")
    axes[2][2].grid(visible=True);
    #for i in range(tot_bridge_nr):
    #     axes[2][2].plot(t_vals, states[2][:,i+tot_bridge_nr]);
    axes[2][2].set_title("n of all "+str(tot_bridge_nr)+" cross-bridges in mtc3")
    axes[2][2].set_ylabel('n')
    axes[2][2].set_xlabel("Time [s]");
    axes[2][2].set_ylim([0,1])
    axes[3][2].grid(visible=True);
    axes[3][2].plot(t_vals, states[2][:,-2]);
    axes[3][2].set_title("l_ce of all "+str(tot_bridge_nr)+" cross-bridges in mtc3")
    axes[3][2].set_ylabel('l [m]')
    axes[3][2].set_xlabel("Time [s]")
    axes[4][2].grid(visible=True);
    axes[4][2].plot(t_vals, lSEs[2]);
    axes[4][2].set_title("l_se of all "+str(tot_bridge_nr)+" cross-bridges in mtc3")
    axes[4][2].set_ylabel('l [m]')
    axes[4][2].set_xlabel("Time [s]")
    axes[0][3].grid(visible=True);
    axes[0][3].plot(t_vals, coords_vals[:,1][:,1:]);
    axes[0][3].set_ylabel('y points [m]')
    axes[0][3].set_xlabel("Time [s]")
    axes[0][3].set_title("Structure movement in y-t")
    axes[0][3].legend(['y0','y1','y2','y3','y4'])
    axes[1][3].grid(visible=True);
    # for i in range(tot_bridge_nr):
    #     axes[1][3].plot(t_vals, states[3][:,i]/mus_vals[0][0]);
    axes[1][3].set_title("x of all "+str(tot_bridge_nr)+" cross-bridges in mtc4")
    axes[1][3].set_ylabel('x [h]')
    axes[1][3].set_xlabel("Time [s]")
    axes[2][3].grid(visible=True);
    # for i in range(tot_bridge_nr):
    #     axes[2][3].plot(t_vals, states[3][:,i+tot_bridge_nr]);
    axes[2][3].set_title("n of all "+str(tot_bridge_nr)+" cross-bridges in mtc4")
    axes[2][3].set_ylabel('n')
    axes[2][3].set_xlabel("Time [s]");
    axes[2][3].set_ylim([0,1])
    axes[3][3].grid(visible=True);
    axes[3][3].plot(t_vals, states[2][:,-2]);
    axes[3][3].set_title("l_ce of all "+str(tot_bridge_nr)+" cross-bridges in mtc4")
    axes[3][3].set_ylabel('l [m]')
    axes[3][3].set_xlabel("Time [s]")
    axes[4][3].grid(visible=True);
    axes[4][3].plot(t_vals, lSEs[3]);
    axes[4][3].set_title("l_se of all "+str(tot_bridge_nr)+" cross-bridges in mtc4")
    axes[4][3].set_ylabel('l [m]')
    axes[4][3].set_xlabel("Time [s]")
    '''
    axes[0][4].grid(visible=True);
    for i in range(muscle_number):
        axes[0][4].plot(t_vals, coords_vals[:,2,i],muscle_color_list[i])
    axes[0][4].set_ylabel('muscle length [m]')
    axes[0][4].set_xlabel("Time [s]")
    axes[0][4].set_title("Muscle lengths")
    axes[0][4].legend(['MTC_1','MTC_2','MTC_3','MTC_4','MTC_5','MTC_6'])
    '''
    if type(optimal_trajectories) != bool:
        axes[0][4].grid(visible=True);
        opt_a1 = np.ones(len(t_vals))*optimal_trajectories[-1,1]
        opt_a2 = np.ones(len(t_vals))*(optimal_trajectories[-1,2]+optimal_trajectories[-1,1])
        if int(tf/h_step) > len(optimal_trajectories[:,1]):
            opt_a1[:len(optimal_trajectories[:,1])] = optimal_trajectories[:,1]
            opt_a2[:len(optimal_trajectories[:,2])] = optimal_trajectories[:,2]+optimal_trajectories[:,1]                    
        if int(tf/h_step) <= len(optimal_trajectories[:,1]):
            opt_a1[:int(tf/h_step)] = optimal_trajectories[:int(tf/h_step),1]
            opt_a2[:int(tf/h_step)] = optimal_trajectories[:int(tf/h_step),2]+optimal_trajectories[:int(tf/h_step),1]

        #opt_a1 = np.ones(len(t_vals))*optimal_trajectories[-1,1]
        #opt_a1[:len(optimal_trajectories[:,1])] = optimal_trajectories[:,1]
        #opt_a2 = np.ones(len(t_vals))*(optimal_trajectories[-1,2]+optimal_trajectories[-1,1])
        #opt_a2[:len(optimal_trajectories[:,2])] = (optimal_trajectories[:,2]+optimal_trajectories[:,1])
        axes[0][4].plot(t_vals,s_vals[:,0],label='a1')
        axes[0][4].plot(t_vals,s_vals[:,1],label='a2')
        axes[0][4].plot(t_vals,opt_a1,label='a1 optimal')
        axes[0][4].plot(t_vals,opt_a2,label='a2 optimal')
        axes[0][4].set_xlabel('time [s]')
        axes[0][4].set_ylabel('joint angle [rad]')
        axes[0][4].legend(loc='right')
        axes[0][4].set_title('Simulated vs optimal joint angles')
    if type(optimal_trajectories) == bool:
        
        axes[0][4].grid(visible=True);
        for i in range(muscle_number):
            axes[0][4].plot(t_vals[1:], K_CE_list[i][1:],muscle_color_list[i]);
        axes[0][4].set_title("CE stiffness over time")
        axes[0][4].set_ylabel('K_CE [N/m]')
        axes[0][4].set_xlabel("t [s]")
        axes[0][4].legend(['MTC_1','MTC_2','MTC_3','MTC_4','MTC_5','MTC_6'])
        
    axes[1][4].grid(visible=True);
    # for i in range(tot_bridge_nr):
    #     axes[1][4].plot(t_vals, states[4][:,i]/mus_vals[0][0]);
    axes[1][4].set_title("x of all "+str(tot_bridge_nr)+" cross-bridges in mtc5")
    axes[1][4].set_ylabel('x [h]')
    axes[1][4].set_xlabel("Time [s]")
    axes[2][4].grid(visible=True);
    # for i in range(tot_bridge_nr):
    #     axes[2][4].plot(t_vals, states[4][:,i+tot_bridge_nr]);
    axes[2][4].set_title("n of all "+str(tot_bridge_nr)+" cross-bridges in mtc5")
    axes[2][4].set_ylabel('n')
    axes[2][4].set_xlabel("Time [s]");
    axes[2][4].set_ylim([0,1])
    axes[3][4].grid(visible=True);
    axes[3][4].plot(t_vals, states[4][:,-2]);
    axes[3][4].set_title("l_ce of all "+str(tot_bridge_nr)+" cross-bridges in mtc5")
    axes[3][4].set_ylabel('l [m]')
    axes[3][4].set_xlabel("Time [s]")
    axes[4][4].grid(visible=True);
    axes[4][4].plot(t_vals, lSEs[4]);
    axes[4][4].set_title("l_se of all "+str(tot_bridge_nr)+" cross-bridges in mtc5")
    axes[4][4].set_ylabel('l [m]')
    axes[4][4].set_xlabel("Time [s]")

    axes[0][5].grid(visible=True)
    for i in range(muscle_number):
        axes[0][5].plot(t_vals, mtc_vels[i],muscle_color_list[i]);
    axes[0][5].set_ylabel('muscle velocity [m/s]')
    axes[0][5].set_xlabel("Time [s]")
    axes[0][5].set_title("Muscle velocities")
    axes[0][5].legend(['MTC_1','MTC_2','MTC_3','MTC_4','MTC_5','MTC_6'])
    axes[1][5].grid(visible=True);
    # for i in range(tot_bridge_nr):
    #     axes[1][5].plot(t_vals, states[5][:,i]/mus_vals[0][0]);
    axes[1][5].set_title("x of all "+str(tot_bridge_nr)+" cross-bridges in mtc6")
    axes[1][5].set_ylabel('x [h]')
    axes[1][5].set_xlabel("Time [s]")
    axes[2][5].grid(visible=True);
    # for i in range(tot_bridge_nr):
    #     axes[2][5].plot(t_vals, states[5][:,i+tot_bridge_nr]);
    axes[2][5].set_title("n of all "+str(tot_bridge_nr)+" cross-bridges in mtc6")
    axes[2][5].set_ylabel('n')
    axes[2][5].set_xlabel("Time [s]");
    axes[2][5].set_ylim([0,1])
    axes[3][5].grid(visible=True);
    axes[3][5].plot(t_vals, states[5][:,-2]);
    axes[3][5].set_title("l_ce of all "+str(tot_bridge_nr)+" cross-bridges in mtc6")
    axes[3][5].set_ylabel('l [m]')
    axes[3][5].set_xlabel("Time [s]")
    axes[4][5].grid(visible=True);
    axes[4][5].plot(t_vals, lSEs[5])
    axes[4][5].set_title("l_se of all "+str(tot_bridge_nr)+" cross-bridges in mtc6")
    axes[4][5].set_ylabel('l [m]')
    axes[4][5].set_xlabel("Time [s]")
    
    for mus in range(6):
        axes[5][mus].grid(visible=True);
        axes[5][mus].plot(t_vals, coords_vals[:,2,mus],label='mtc length')
        if type(optimal_trajectories) != bool:
            axes[5][mus].plot(t_vals, optimal_muscle_lengths[:,mus],label='optimal mtc length');
            axes[5][mus].set_title("l_mtc and target of mtc"+str(mus+1))
        if type(optimal_trajectories) == bool:
            axes[5][mus].set_title("l_mtc of mtc"+str(mus+1))    
        axes[5][mus].set_ylabel('l [m]')
        axes[5][mus].set_xlabel("Time [s]")
        axes[5][mus].legend()
    
    
    
    
    if save == True:
        if specific_save_name != False:
            fig.savefig('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_3+2b/Results/full_plot_'+str(save_name)+'__'+str(specific_save_name)+'.png')
        if specific_save_name == False:
            fig.savefig('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_3+2b/Results/full_plot_'+str(save_name)+'_'+time.ctime());
    return 
    




def plot_huxley_single_muscle(t_vals, s_vals, coords_vals,mtc_vels,calculated_huxley_force,states,activation,t0,tf,t_pertubation,h_step,muscle_number,tot_bridge_nr,step_nr,mus_vals,p,v_type,FL_type,f_type,K_SE_list,K_CE_list,lCEs,lSEs,save=True,save_name=False,specific_save_name=False):
    #calculated_huxley_force = calculated_muscle_forces[:][:][2]
    #%%time
    #plt.rcParams["figure.figsize"] = (8, 6)
    fig, axes = plt.subplots(3,3,figsize=(20,20));
    fig.suptitle(str(h_step)+' steps, '+str(v_type)+str(FL_type)+str(f_type)+'fmax1: '+str(mus_vals[0][7])+',thelen, m3: '+str(p[10])+', J3: '+str(p[11]))
    
    muscle_color_list   =['salmon','turquoise','darkblue','lime','magenta','gold']
    br_list = [(0.1,0.0,1.0),(0.2,0.0,0.9),(0.3,0.0,0.8),(0.4,0.0,0.7),(0.5,0.0,0.6),(0.6,0.0,0.5),(0.7,0.0,0.4),(0.8,0.0,0.3),(0.9,0.0,0.2),(1.0,0.0,0.1)]#color = [(0.3,0.3,0.5)]
    axes[0][0].grid(visible=True);
    axes[0][0].plot(t_vals, activation[0],muscle_color_list[0]);
    axes[0][0].set_title("Excitation over time mtc1")#, Winters, "+ str(h_step)+' stepsize,old v,old f,FLhills,bigfmax, thelen'
    axes[0][0].set_ylabel('Excitation [-]')
    axes[0][0].set_xlabel("Time [s]");
    
    axes[1][0].grid(visible=True);
    for i in range(tot_bridge_nr):
        axes[1][0].plot(t_vals, states[0][:,i]/mus_vals[0][0]);
    axes[1][0].set_title("x of all "+str(tot_bridge_nr)+" cross-bridges in mtc1")
    axes[1][0].set_ylabel('x [h]')
    axes[1][0].set_xlabel("Time [s]")
    axes[2][0].grid(visible=True);
    for i in range(tot_bridge_nr):
        axes[2][0].plot(t_vals, states[0][:,i+tot_bridge_nr]);
    axes[2][0].set_title("n of all "+str(tot_bridge_nr)+" cross-bridges in mtc1")
    axes[2][0].set_ylabel('n')
    axes[2][0].set_xlabel("Time [s]")
    axes[2][0].set_ylim([0,1])
    
    axes[0][1].grid(visible=True);
    axes[0][1].plot(t_vals, calculated_huxley_force[0],muscle_color_list[0]);
    axes[0][1].set_ylabel('Muscle force [N]')
    axes[0][1].set_xlabel("Time [s]")
    axes[0][1].set_title("Muscle Forces in mtc1")
    axes[1][1].grid(visible=True)
    axes[1][1].plot(t_vals, mtc_vels[0],muscle_color_list[0]);
    axes[1][1].set_ylabel('muscle velocity [m/s]')
    axes[1][1].set_xlabel("Time [s]")
    axes[1][1].set_title("Muscle velocities in mtc1")
    axes[2][1].grid(visible=True);
    axes[2][1].plot(t_vals, coords_vals[:,0][:,1:]);
    axes[2][1].set_ylabel('x points [m]')
    axes[2][1].set_xlabel("Time [s]")
    axes[2][1].set_title("Structure movement in x-t")
    axes[2][1].legend(['x0','x1','x2','x3','x4'])
    
    axes[0][2].grid(visible=True);
    axes[0][2].plot(t_vals[1:], K_CE_list[0][1:],muscle_color_list[0]);
    axes[0][2].set_title("CE stiffness over time in mtc1")
    axes[0][2].set_ylabel('K_CE [N/m]')
    axes[0][2].set_xlabel("t [s]")
    axes[1][2].grid(visible=True);
    axes[1][2].plot(t_vals, states[0][:,-2]);
    axes[1][2].set_title("l_ce of all "+str(tot_bridge_nr)+" cross-bridges in mtc1")
    axes[1][2].set_ylabel('l [m]')
    axes[1][2].set_xlabel("Time [s]")
    axes[2][2].grid(visible=True);
    axes[2][2].plot(t_vals, lSEs[0])
    axes[2][2].set_title("l_se of all "+str(tot_bridge_nr)+" cross-bridges in mtc1")
    axes[2][2].set_ylabel('l [m]')
    axes[2][2].set_xlabel("Time [s]")
    
    
    if save == True:
        if specific_save_name != False:
            fig.savefig('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_3+2b/Results/sm_plot_'+str(save_name)+'__'+str(specific_save_name)+'.png')
        if specific_save_name == False:
            fig.savefig('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_3+2b/Results/sm_plot_'+str(save_name)+'_'+time.ctime());
    return 





def plot_hill_full(t_vals, s_vals, coords_vals,mtc_vels,calculated_muscle_forces,states,activation,t0,tf,t_pertubation,h_step,muscle_number,tot_bridge_nr,step_nr,mus_vals,save=True,save_name=False,specific_save_name=False,optimal_trajectories=False,optimal_muscle_lengths=False):
    #calculated_huxley_force = calculated_muscle_forces[:][:][2]
    #%%time
    #plt.rcParams["figure.figsize"] = (8, 6)
    #muscle_color_list   =['salmon','turquoise','darkblue','lime','magenta','gold']
    muscle_color_list   =['salmon','magenta','turquoise','darkblue','lime','gold']
    br_list = [(0.1,0.0,1.0),(0.2,0.0,0.9),(0.3,0.0,0.8),(0.4,0.0,0.7),(0.5,0.0,0.6),(0.6,0.0,0.5),(0.7,0.0,0.4),(0.8,0.0,0.3),(0.9,0.0,0.2),(1.0,0.0,0.1)]#color = [(0.3,0.3,0.5)]

    #muscle_color_list_2 =['salmon','lime','slateblue']
    fig, axes = plt.subplots(4,3,figsize=(20,24));
    #fig.suptitle(str(p)+str(r)+str(muscle_pars_1)+'t0: '+str(t0)+', tf: '+str(tf)+', h: '+str(h_step))
    axes[0][0].grid(visible=True);
    for i in range(muscle_number):
        axes[0][0].plot(t_vals, activation[i],muscle_color_list[i]);
    #for i in range(muscle_number):    
    #    axes[0][0].plot(t_vals, states[i][:,-1],muscle_color_list[i]);
    axes[0][0].set_title("Excitation over time")
    axes[0][0].set_ylabel('Excitation [-]')
    axes[0][0].set_xlabel("Time [s]");
    axes[0][0].legend(['MTC_1','MTC_2','MTC_3','MTC_4','MTC_5','MTC_6'])
    
    axes[0][1].grid(visible=True);
    for i in range(muscle_number):
        axes[0][1].plot(t_vals, calculated_muscle_forces[i],muscle_color_list[i]);
    axes[0][1].set_ylabel('Muscle force [N]')
    axes[0][1].set_xlabel("Time [s]")
    axes[0][1].set_title("Muscle Forces")
    axes[0][1].legend(['MTC_1','MTC_2','MTC_3','MTC_4','MTC_5','MTC_6'])
    
    axes[0][2].grid(visible=True);
    axes[0][2].plot(t_vals, coords_vals[:,0]);
    axes[0][2].set_ylabel('x points [m]')
    axes[0][2].set_xlabel("Time [s]")
    axes[0][2].set_title("Structure movement in x-t")
    axes[0][2].legend(['x0','x1','x2','x3 ','x4'])
    
    axes[1][0].grid(visible=True);
    axes[1][0].plot(t_vals, coords_vals[:,1]);
    axes[1][0].set_ylabel('y points [m]')
    axes[1][0].set_xlabel("Time [s]")
    axes[1][0].set_title("Structure movement in y-t")
    axes[1][0].legend(['y0','y1','y2','y3 ','y4'])
    axes[1][1].grid(visible=True);
    for i in range(muscle_number):
        axes[1][1].plot(t_vals, coords_vals[:,2,i]/coords_vals[:,2,i][0],muscle_color_list[i]);
    axes[1][1].set_ylabel('muscle length [m]')
    axes[1][1].set_xlabel("Time [s]")
    axes[1][1].set_title("Muscle length changes")
    axes[1][1].legend(['MTC_1','MTC_2','MTC_3','MTC_4','MTC_5','MTC_6'],loc='best')
    axes[1][2].grid(visible=True)
    for i in range(muscle_number):
        axes[1][2].plot(t_vals, mtc_vels[i],muscle_color_list[i]);
    axes[1][2].set_ylabel('muscle velocity [m/s]')
    axes[1][2].set_xlabel("Time [s]")
    axes[1][2].set_title("Muscle velocities")
    axes[1][2].legend(['MTC_1','MTC_2','MTC_3','MTC_4','MTC_5','MTC_6'])
    '''
    axes[2][0].grid(visible=True);
    for i in range(muscle_number):
        axes[2][0].plot(t_vals[int(t_pertubation/h_step):], calculated_muscle_forces[i][int(t_pertubation/h_step):],muscle_color_list[i])
    axes[2][0].set_ylabel('Muscle force zoomed[N]')
    axes[2][0].set_xlabel("Time [s]")
    axes[2][0].set_title("Muscle Forces")
    axes[2][0].legend(['MTC_1','MTC_2','MTC_3','MTC_4','MTC_5','MTC_6'])'''
    
    
    for mus in range(3):
        axes[2][mus].grid(visible=True);
        axes[2][mus].plot(t_vals, coords_vals[:,2,mus],label='mtc length')
        if type(optimal_trajectories) != bool:
            axes[2][mus].plot(t_vals, optimal_muscle_lengths[:,mus],label='optimal mtc length');
            axes[2][mus].set_title("l_mtc and target of mtc"+str(mus+1))
        if type(optimal_trajectories) == bool:
            axes[2][mus].set_title("l_mtc of mtc"+str(mus+1))    
        axes[2][mus].set_ylabel('l [m]')
        axes[2][mus].set_xlabel("Time [s]")
        axes[2][mus].legend()
    for mus in range(3):
        axes[3][mus].grid(visible=True);
        axes[3][mus].plot(t_vals, coords_vals[:,2,mus+3],label='mtc length')
        if type(optimal_trajectories) != bool:
            axes[3][mus].plot(t_vals, optimal_muscle_lengths[:,mus+3],label='optimal mtc length');
            axes[3][mus].set_title("l_mtc and target of mtc"+str(mus+4))
        if type(optimal_trajectories) == bool:
            axes[3][mus].set_title("l_mtc of mtc"+str(mus+4))    
        axes[3][mus].set_ylabel('l [m]')
        axes[3][mus].set_xlabel("Time [s]")
        axes[3][mus].legend()
    if save == True:
        if specific_save_name != False:
            fig.savefig('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_3+2b/Results/full_plot_'+str(save_name)+'__'+str(specific_save_name)+'.png');
        if specific_save_name == False:
            fig.savefig('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_3+2b/Results/full_plot_'+str(save_name)+'_'+time.ctime());
    return 

def plot_movement_static(t_vals, s_vals, coords_vals,mtc_vels,calculated_huxley_force,states,activation,t0,tf,h_step,muscle_number,tot_bridge_nr,step_nr,mus_vals,save=True,save_name=False,specific_save_name=False):
    plt.close("all")
    muscle_color_list   =['salmon','turquoise','darkblue','lime','magenta','gold']
    br_list = [(0.1,0.0,1.0),(0.2,0.0,0.9),(0.3,0.0,0.8),(0.4,0.0,0.7),(0.5,0.0,0.6),(0.6,0.0,0.5),(0.7,0.0,0.4),(0.8,0.0,0.3),(0.9,0.0,0.2),(1.0,0.0,0.1)]
    fig, axes = plt.subplots(1,1,figsize=(10,10));
    axes.grid(visible=True);
    axes.plot(coords_vals[-1,0,0],coords_vals[-1,1,0],'go');
    for i in range(2):
        axes.plot(coords_vals[:,0,i], coords_vals[:,1,i],muscle_color_list[i+1],linestyle='dashed',linewidth=2,alpha=0.8);
    axes.plot(coords_vals[0,0,2:],coords_vals[0,1,2:],'bo');
    axes.plot(coords_vals[-1,0,2:],coords_vals[-1,1,2:],'ro');
    axes.plot(coords_vals[0,0,0:],coords_vals[0,1,0:],'b',linewidth=4);
    axes.plot(coords_vals[-1,0,0:],coords_vals[-1,1,0:],'r',linewidth=4);

    axes.set_ylabel('y points [m]')
    axes.set_xlabel("x points [m]")
    #axes.set_xlim(-0.35,0.35)
    axes.set_title("Structure movement in x-y")
    axes.legend(['x0','x1 movement','x2 movement','x3 movement','x4 movement','start position','end position'])
    for i in range(len(br_list)):
        axes.plot(coords_vals[int(len(coords_vals[:,0,0:])*i/11),0,0:],coords_vals[int(len(coords_vals[:,0,0:])*i/11),1,0:],marker='.',color = br_list[i],alpha=0.4,linewidth=3);
        #axes.plot(coords_vals[int(len(coords_vals[:,0,0:])*i/11),0,0:],coords_vals[int(len(coords_vals[:,0,0:])*i/11),1,0:],color = br_list[i],alpha=0.3,linewidth=3)
    if save == True:
        if specific_save_name != False:
            fig.savefig('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_3+2b//move_plot_'+str(save_name)+'__'+str(specific_save_name)+'.png');
        if specific_save_name == False:
            fig.savefig('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_3+2b/Results/move_plot_'+str(save_name)+'_'+time.ctime());
    return
