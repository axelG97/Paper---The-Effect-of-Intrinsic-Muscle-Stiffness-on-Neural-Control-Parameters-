
import sympy as sm
import numpy as np
import scipy
from scipy.optimize import fsolve
#from scipy.io import *
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import IPython
from IPython.display import display, HTML
from scipy.integrate import quad
from scipy.integrate import odeint
import random
from numba import jit, int32
import time
from mpl_toolkits.mplot3d import Axes3D
import math
from scipy.optimize import curve_fit
import xarray
#import pandas as pd
import mat4py
from geneticalgorithm import geneticalgorithm as ga
#import nbkode