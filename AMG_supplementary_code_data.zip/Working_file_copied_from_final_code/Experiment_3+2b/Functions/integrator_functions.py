from general_functions import *
from muscle_functions import *
from matrices_functions import *
from constants_functions import *

def rk4_integrator(f, t0, tf, s0, t_pertubation, pert_vals,h_step, r_vals, muscle_number,tot_bridge_nr, eval_xs, eval_ys, eval_ls, p_vals,mus_vals,Fmax_muscles,f_factor,reduce_drift=False,manual_input_STIM=False,input_STIM=False,initial_pauze=True,muscle_limit=True,model_type='huxley',hill_type='thijs',v_type='v_old',FL_type='FL_0',straight_og=True,specific_save_name=False,experiment_name=False,opt_trajectories=False,feedback_vector=False,add_feedback=False):#change entirely for lce
    #some variables that the loop will use to keep track
    t_span = [t0,tf]
    step_nr = int((t_span[1]-t_span[0])/h_step)
    steps_per_second = step_nr / tf
    starting_step = int((0.01/tf)*step_nr)
    STIM = [[]]*muscle_number #for debug purposes
    '''Integrate the function f and return the time values and associated state values. This function uses an rk4 integrator.
    
    Parameters
    -----------------------------------------
    f : function
        Evaluates the right hand side of the first order differential equation in form f(t, s).
    t_span : 2-tuple
        Start time and stop time [s], [t0,tf]
    s0 : array_like, shape(6,)
        Initial values of the environment states in order [alpha1, alpha2, alpha3, alpha1', alpha2', alpha3'].
    t_pertubation : float
        Time value where the perturbation is applied.
    pert_vals : 
        Perturbation values of the environment states, to be added to the state vector at t=t_pertubation in the order [alpha1, alpha2, alpha3, alpha1', alpha2', alpha3'].
    h_step : float
        Step size [s]
    muscle_number : float
        number of muscles in the system
    step_nr : float
        Total number of steps in the simulation 
    r_vals : list, shape(muscle_number,)
        list of forces applied by each muscle. This is updated after each step.
    tot_bridge_nr : float
        Number of cross-bridges in each muscle
    eval_xs : function
        Evaluation function that takes in the states of the environment s and returns the x-coordinates 
    eval_ys : function
        Evaluation function that takes in the states of the environment s and returns the y-coordinates 
    eval_ls : function
        Evaluation function that takes in the states of the environment s and returns the muscle lengths
    mus_vals : array, shape(muscle_number,43)
        muscle constants for all muscles 
    Fmax_muscles : 
        Relic of a removed variable, only relevant for Exp2a
    f_factor : Int
        Determines how much the muscle forces are scaled
    reduce_drift : boolean
        Relic of an old drift removal function
    manual_input_STIM : boolean
        If True, the STIM vector wil be equal to the input_STIM
    input_STIM : list, shape(muscle_number,step_nr) or a string in the set ['full','step','inverse_ramp','ramp','alt_step']
        If manual_input_STIM is False and input_STIM is equal to a string in the list, a STIM pattern will be used
    initial_pauze : boolean
        Relic of an old pauze function
    muscle_limit : boolean
        Relic of an old muscle limit function
    model_type : string
        Determines the current muscle model, either 'huxley' or 'hill'
    hill_type : string
        If model_type is 'hill' this determines the current muscle model, either 'thijs' for the Hill_expanded model or 'stroeve' for the Hill_simple model    
    v_type : string
        If model_type is 'huxley' this determines the current v_ce model, either 'v_old' for the used model or 'v_new' for the extended model in (Vardy)
    FL_type : string
       This determines the current FL model, either 'FL_huxley' or 'FL_Hill'(used)
    straight_og : boolean
        If True, the current_muscle_starting_lengths will be defined with the arm in the straight up position
    specific_save_name : string
        If not False, determines a portion of the save name in of the files in the save_functions.py or plot_functions.py functions
    experiment_name : string
        If not False, determines a portion of the save name in of the files in the save_functions.py or plot_functions.py functions. In addition, determines the starting stiffness position of the muscle in the constant_altering_function(). Must include one in set [stiff_start_mostpos, stiff_start_verypos,stiff_start_newpos,stiff_start_newneg,stiff_start_mostneg,stiff_start_extraneg]
    opt_trajectories : tuple
        If not False, contains the optimal trajectory information for slightly differently designed angles in Flash and Hogan, shape(751,7)
    feedback_vector : array
        array of length(4) containing the feedback vector parameters 
    add_feedback : boolean
        If True, the feedback system will be used to change the STIM parameter
    
    Returns
    -----------------------------------------
    t : ndarray, shape(step_nr,)
        Array of time values spanning t_span
    s : ndarray, shape(step_nr, 6)
        Array of environment state values at each timestep 
    coords : ndarray, shape(step_nr,(3,3,6))
        Array of environment coordinates in the order [x1...xi,y1...yi,lmtc1..lmtci] (currently xm1 at the end)
    mtc_vels : ndarray, shape(muscle_number,step_nr)
        Array of muscle-tendon complex (mtc) velocities per timestep
    total_muscle_forces : ndarray, shape(muscle_number,step_nr)
        Array of mtc forces per timestep
    states : ndarray, shape(muscle_number,step_nr,tot_bridge_nr,tot_bridge_nr*2 + 2)
        Array of all the huxley state variables in the order [x1...xi,n1...ni,lce,activation] at each timestep
    STIM : ndarray, shape(muscle_number,step_nr)
        Array of all the applied stimulations at each timestep 
    mus_vals_changed : ndarray, shape(muscle_number,43)     
        Updated muscle constants for all muscles
    K_SE_list : ndarray, shape(muscle_number,step_nr)
        If model_type is 'huxley', contains a vector of all the SE stiffness values. Otherwise is list of zeros
    K_CE_list : ndarray, shape(muscle_number,step_nr)
        If model_type is 'huxley', contains a vector of all the CE stiffness values. Otherwise is list of zeros
    calculated_muscle_forces : ndarray, shape(muscle_number,step_nr,3-9)
        Array of mtc forces vector per timestep, differently sized depending on muscle model
    '''
    
    #different stimulation patterns
    if manual_input_STIM != False:
        STIM = input_STIM
    if manual_input_STIM == False:
        STIM = np.ones((muscle_number,len(step_nr)))
     
    #this changes some muscle parameters, creates empty lists and sets up the initial states
    total_muscle_forces      = np.zeros((muscle_number,step_nr+2))
    if model_type == 'huxley':
        states = np.zeros((muscle_number,step_nr+2,tot_bridge_nr*2+2))
        calculated_muscle_forces = np.zeros((muscle_number,step_nr+2,3))
    if model_type == 'hill':
        states = np.zeros((muscle_number,step_nr+2,2))
        calculated_muscle_forces = np.zeros((muscle_number,step_nr+2,9))
        fmax_list = np.zeros(6)
        for muscle in range(muscle_number):
            fmax_list[muscle] = mus_vals[muscle][7]*f_factor
    mtc_vels = np.zeros((muscle_number,step_nr+2))
    K_SE_list = np.zeros((muscle_number,step_nr+2))#create the stiffness vectors
    K_PE_list = np.zeros((muscle_number,step_nr+2))
    K_CE_list = np.zeros((muscle_number,step_nr+2))

    #change initial muscle lengths if true
    if straight_og != True:
        current_muscle_start_lengths = eval_ls(s0[:3], p_vals)#original
    if straight_og == True:
        s0_og = [0.5*np.pi,0.5*np.pi,0,0,0,0] 
        current_muscle_start_lengths = eval_ls(s0_og[:3], p_vals)
        
    mus_vals_changed,states = constant_altering_function(mus_vals,current_muscle_start_lengths,states,muscle_number,tot_bridge_nr,model_type,hill_type,specific_save_name,experiment_name)
   
    t0 = t_span[0]
    tf = t_span[1]
    s = [s0]
    t = [t0]
    coords = [plot_points(s0,eval_xs,eval_ys,eval_ls,p_vals)]
    nul_lengths = [np.array(coords)[0][2][:]]
    ti = t0
    si = s0
    previous_coords = coords #for debug purposes
    a = 0   #repetition counter
    while a <= step_nr:
        #rk4 integration
        t_counter = ti
        k1 = f(ti, si,r_vals)
        k2 = f(ti + h_step/2, si + h_step/2*k1,r_vals)
        k3 = f(ti + h_step/2, si + h_step/2*k2,r_vals)
        k4 = f(ti + h_step, si + h_step*k3,r_vals)
        si = si + h_step/6*(k1 + 2*k2 + 2*k3 + k4)
        ti += h_step
        if (t_pertubation != False) and (a*h_step == t_pertubation):#apply the pertubation at the right time
            si[0],si[1],si[2],si[3],si[4],si[5] = si[0]+pert_vals[0],si[1]+pert_vals[1],si[2]+pert_vals[2],si[3]+pert_vals[3],si[4]+pert_vals[4],si[5]+pert_vals[5]
        s.append(si)
        t.append(ti)
        current_coords = plot_points(si,eval_xs,eval_ys,eval_ls,p_vals) 
        
        #muscle precalculations
        for current_muscle in range(muscle_number): #iterate over all muscles, calculate current velocity based of off difference in lengths
            if a == 0:
                mtc_vels[current_muscle][a] = (current_coords[2][current_muscle]-nul_lengths[0][current_muscle])/h_step 
            if a > 0: 
                mtc_vels[current_muscle][a] = (current_coords[2][current_muscle]-previous_coords[2][current_muscle])/h_step
        coords.append(current_coords)
        previous_coords = current_coords
        a += 1
        if type(opt_trajectories) != bool:
            if a <=750: #length of optimal value vector
                optimal_muscle_lengths = eval_ls([opt_trajectories[:,1][a-1],opt_trajectories[:,2][a-1]+opt_trajectories[:,1][a-1],0],p_vals)#determine optimal muscle lengths at this time
                optimal_muscle_vels = (np.array(optimal_muscle_lengths)-np.array(eval_ls([opt_trajectories[:,1][a-2],opt_trajectories[:,2][a-2]+opt_trajectories[:,1][a-2],0],p_vals)))/h_step#determine optimal muscle velocity at this time
            if a >750: #length of optimal value vector
                optimal_muscle_lengths = eval_ls([opt_trajectories[:,1][750],opt_trajectories[:,2][750]+opt_trajectories[:,1][750],0],p_vals)#determine optimal muscle lengths at this time
                optimal_muscle_vels = np.zeros(muscle_nr)#determine optimal muscle velocity at this time
                
        #muscle dynamics calculations
        for current_muscle in range(muscle_number): #iterate over all muscles 
            l_mtc = current_coords[2][current_muscle]
            v_mtc = mtc_vels[current_muscle][a-1]
            if add_feedback != False:#feedback system
                if len(feedback_vector)>4:
                    new_STIM = reflex_feedback(l_mtc,v_mtc,optimal_muscle_lengths[current_muscle],optimal_muscle_vels[current_muscle],feedback_vector[4*(current_muscle):4*(current_muscle+1)],STIM[current_muscle][a-2])
                if len(feedback_vector)<=4:
                    new_STIM = reflex_feedback(l_mtc,v_mtc,optimal_muscle_lengths[current_muscle],optimal_muscle_vels[current_muscle],feedback_vector,STIM[current_muscle][a-2])
                STIM[current_muscle][a-1]=new_STIM    
            states_previous_step = states[current_muscle][a-1]
            states_previous_step2 = states[current_muscle][a-2]
            calculated_muscle_forces_previous_step = calculated_muscle_forces[current_muscle][a-1][:]
            if model_type == 'huxley':
                F_per_step, state_current_step,K_SE_list[current_muscle][a],K_CE_list[current_muscle][a] = huxley(l_mtc,v_mtc,states_previous_step,t_counter,h_step, mus_vals_changed[current_muscle],tot_bridge_nr,STIM[current_muscle][a-1],False,True,FL_type,v_type,states_previous_step2,calculated_muscle_forces_previous_step)#calculates the muscle force per muscle per cross-bridge for the current length and velocity values 
                r_vals[current_muscle] = np.sum(F_per_step[2]) #stores the muscle force into the array that the environment simulator uses 
                total_muscle_forces[current_muscle][a] = F_per_step[2] 
                
            if model_type == 'hill':
                F_per_step, state_current_step = hill(l_mtc,v_mtc,states_previous_step,calculated_muscle_forces_previous_step,t_counter,h_step, mus_vals_changed[current_muscle],STIM[current_muscle][a-1],hill_type,FV_type='FV_hill',a_func=True)
                if hill_type == 'thijs':
                    F_per_step[0],F_per_step[1],F_per_step[2],F_per_step[3] = F_per_step[0]*fmax_list[current_muscle],F_per_step[1]*fmax_list[current_muscle],F_per_step[2]*fmax_list[current_muscle],F_per_step[3]*fmax_list[current_muscle]
                total_muscle_forces[current_muscle][a] = F_per_step[0]
                K_SE_list=0
                K_CE_list=0
                r_vals[current_muscle] = np.sum(F_per_step[0]) #stores the muscle force into the array that the environment simulator uses 
            states[current_muscle][a] = state_current_step
            calculated_muscle_forces[current_muscle][a][:] = F_per_step[:] #sum the calculated CE forces for this timestep and put into force array
    return np.array(t),np.array(s),np.array(coords),np.array(mtc_vels),np.array(total_muscle_forces),np.array(states),np.array(STIM),mus_vals_changed,np.array(K_SE_list),np.array(K_CE_list),np.array(calculated_muscle_forces)

#function that calculates the coordinates of the system in x,y as well as the muscle lengths l
def plot_points(s,eval_xs,eval_ys,eval_ls,p_vals):
    #create numerical functions to return coordinates to plot
    xs = eval_xs(s[:3], p_vals)
    ys = eval_ys(s[:3], p_vals)
    ls = eval_ls(s[:3], p_vals)
    return xs, ys, ls