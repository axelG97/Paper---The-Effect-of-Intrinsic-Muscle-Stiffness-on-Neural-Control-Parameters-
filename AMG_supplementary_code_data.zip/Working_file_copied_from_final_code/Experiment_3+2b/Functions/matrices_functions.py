#The basis for this code has been provided by Dr. Jason Moore, for the TU Delft course of Multibody Dynamics 2020-2021
from general_functions import * 

#function that updates the force and generalise coordinate vectors
def F_M_vars_calc(l1, l2,l3,l4,m1, m2, J1, J2,F_mtc1,F_mtc2,F_mtc3,F_mtc4,F_mtc5,F_mtc6,r1,r2,t,alpha1,alpha2,x0,x1,x2,x3,x4,y0,y1,y2,y3,y4,p,r,J3,m3,alpha3,B1,B2,thetar1,thetar2,PE_sh1,PE_sh2,PE_xm1,PE_xm2,T_max1,T_max2,f_type=False):
    M_newton = sm.diag(J1, m1, m1,J2,m2,m2,J3,m3,m3)
    
    #passive torques (Stroeve). This is the damping that can be applied
    T_1_shoulder = -B1*alpha1.diff(t)-sm.sign(alpha1-thetar1)*T_max1*(sm.exp(PE_sh1*sm.Abs(alpha1-thetar1)/PE_xm1)-1)/(sm.exp(PE_sh1)-1)
    T_2_elbow = -B2*alpha2.diff(t)-sm.sign(alpha2-thetar2)*T_max2*(sm.exp(PE_sh2*sm.Abs(alpha2-thetar2)/PE_xm2)-1)/(sm.exp(PE_sh2)-1)
    
    #forces, defined in the same direction as positive
    #in this version, the direction of the forces on the body is always the same
    #add forces to system in the form of moment arm, positive moment is against the clock

    #no gravity case
    if f_type == 'f_damped_0grav':
        F_newton = sm.Matrix([(-1*(-F_mtc1+F_mtc2))*r1+(F_mtc6-F_mtc5)*0.025+T_1_shoulder,0,0,1*(-F_mtc4+F_mtc3)*r2+(-F_mtc6+F_mtc5)*0.04+T_2_elbow,0,0,0,0,0])
    if f_type == 'f_undamped_0grav':
        F_newton = sm.Matrix([(-1*(-F_mtc1+F_mtc2))*r1+(F_mtc6-F_mtc5)*0.025,0,0,1*(-F_mtc4+F_mtc3)*r2+(-F_mtc6+F_mtc5)*0.04,0,0,0,0,0])
    #full gravity in each limb
    if f_type == 'f_damped_fullgrav':
        F_newton = sm.Matrix([(-1*(-F_mtc1+F_mtc2))*r1+(F_mtc6-F_mtc5)*0.025+T_1_shoulder,0,-m1*9.81,1*(-F_mtc4+F_mtc3)*r2+(-F_mtc6+F_mtc5)*0.04+T_2_elbow,0,-m2*9.81,0,0,-m3*9.81])
    if f_type == 'f_undamped_fullgrav':
        F_newton = sm.Matrix([(-1*(-F_mtc1+F_mtc2))*r1+(F_mtc6-F_mtc5)*0.025,0,-m1*9.81,1*(-F_mtc4+F_mtc3)*r2+(-F_mtc6+F_mtc5)*0.04,0,-m2*9.81,0,0,-m3*9.81])
    #partial gravity or only m3
    if f_type == 'f_damped_pgrav':
        F_newton = sm.Matrix([(-1*(-F_mtc1+F_mtc2))*r1+(F_mtc6-F_mtc5)*0.025+T_1_shoulder,0,0,1*(-F_mtc4+F_mtc3)*r2+(-F_mtc6+F_mtc5)*0.04+T_2_elbow,0,0,0,0,-m3*9.81])
    if f_type == 'f_undamped_pgrav':
        F_newton = sm.Matrix([(-1*(-F_mtc1+F_mtc2))*r1+(F_mtc6-F_mtc5)*0.025,0,0,1*(-F_mtc4+F_mtc3)*r2+(-F_mtc6+F_mtc5)*0.04,0,0,0,0,-m3*9.81])
    
    #Set up a common function argument structure for all numerical functions we will use:
    p_args = (l1, l2,l3,l4,m1, m2, J1, J2,r1,r2,m3,J3,B1,B2,thetar1,thetar2,PE_sh1,PE_sh2,PE_xm1,PE_xm2,T_max1,T_max2)          # constants
    r_args = (F_mtc1,F_mtc2,F_mtc3,F_mtc4,F_mtc5,F_mtc6)  # specifieds
    q_args = (alpha1,alpha2,alpha3)                              # coordinates
    qd_args = (alpha1.diff(t),alpha2.diff(t),alpha3.diff(t))             # speeds
    return F_newton, M_newton, q_args, qd_args, p_args, r_args 

#functions that performs the neccesary linear algebra 
def matrices_func(M_newton, F_newton, q_args, qd_args, p_args, r_args,T_mat,x,q,t):
    #convective terms
    g_conv = x.diff(t, 2).xreplace({qddi: 0 for qddi in q.diff(t, 2)})
    #reduced mass matrix
    M_tmt = T_mat.transpose()*M_newton*T_mat
    M_tmt = sm.trigsimp(M_tmt)
    #add the reduced forcing terms
    Q_tmt = T_mat.transpose()*(F_newton - M_newton*g_conv)
    #Q_tmt = sm.simplify(Q_tmt) #This step takes very long, do not repeat
    #add constraint column
    C = sm.Matrix([
        0,
        0,
    ])
    Cdd = C.diff(t, 2)
    #extract the terms to augment the mass matrix 
    C_M = Cdd.jacobian(q.diff(t, 2))
    C_Q = -Cdd.xreplace({qdd: 0 for qdd in q.diff(t, 2)})
    #form the constraint augmented mass matrix
    A = M_tmt.row_join(C_M.transpose()).col_join(C_M.row_join(sm.zeros(2, 2)))
    #add the constraint augmented forcing terms
    b = Q_tmt.col_join(C_Q)
    #Create functions that numerically evaluate  A  and  b :
    eval_A = sm.lambdify((q_args, qd_args, p_args, r_args), M_tmt)
    eval_b = sm.lambdify((q_args, qd_args, p_args, r_args), Q_tmt)
    #define jacobian of constraints, zeros in this case
    Cq = C.jacobian(q)
    Cd = C.diff(t)
    #evaluate the constrains, its time derivative and the jacobian
    eval_C = sm.lambdify((q_args, qd_args, p_args, r_args), C)  # shape(2,1)
    eval_Cd = sm.lambdify((q_args, qd_args, p_args, r_args), Cd)  # shape(2,1)
    eval_Cq = sm.lambdify((q_args, qd_args, p_args, r_args), Cq)  # shape(2,3)
    return M_tmt, Q_tmt, C_M, C_Q, A, b, eval_A, eval_b, eval_C, eval_Cd, eval_Cq,g_conv

#function that evaluates the right hand side of the first order DAE's
def eval_rhs(t, s, p, r, eval_A, eval_b):
    """Return the derivatives of the generalized coordinates and speeds plus the Lagrange multipliers
    at a specific time with a provided set of constants.
    
    Parameters
    ==========
    t : float
        Value of time at this instant in seconds.
    s : array_like, shape(6,)
        Generalized coordinate and speed values in order [alpha1, alpha2, alpha3, alpha1', alpha2', alpha3'] at time t.
    p : array_like, shape(14,)
        Constant values in order [l1, l2, l3,l4,m1,J1,m2,J2,r1,r2,m3,J3,B1,B2,thetar1,thetar2,PE_sh1,PE_sh2,PE_xm1,PE_xm2,T_max1,T_max2].
    r : array_like, shape(2,)
        Specified values of time in order [F_mtc1,F_mtc2,F_mtc3,F_mtc4,F_mtc5,F_mtc6]

    Returns
    =======
    sdot : ndarray, shape(6,)
        Time derivatives of the generalized coordinates and speeds at time t in order [alpha1', alpha2', alpha3',
        alpha1'', alpha2'', alpha3''].
    lam : ndarray, shape(3,)
        Lagrange multipliers [constraint @ D, constraint @ E].
    
    """
    alpha1_dot = s[3]
    alpha2_dot = s[4]
    alpha3_dot = s[5]
    
    # evaluate the equation of motion matrices
    A = eval_A(s[:3], s[3:], p, r)  # shape(5, 5)
    b = eval_b(s[:3], s[3:], p, r).squeeze() #  shape(5,)

    # solve the linear system to get the accelerations and Lagrange multipliers

    x = np.linalg.solve(A, b)
    q_dot = x[:3]
    lam = x[3:]
    
    alpha1_ddot = x[0]
    alpha2_ddot = x[1]
    alpha3_ddot = x[2]
    
    # package the derivatives into a NumPy array in the correct order
    qddot = np.array([alpha1_dot,alpha2_dot,alpha3_dot,alpha1_ddot,alpha2_ddot,alpha3_ddot])
    return qddot, lam




