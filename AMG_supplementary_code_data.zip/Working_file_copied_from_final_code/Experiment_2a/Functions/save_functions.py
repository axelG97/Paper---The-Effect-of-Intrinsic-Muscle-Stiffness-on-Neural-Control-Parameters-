from general_functions import *
from muscle_functions import *
from matrices_functions import *
from constants_functions import *
import xarray as xr

#new--
#drive.mount('/content/drive')
#root_path = 'drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_2a'
#sys.path.append(root_path)
#--


def save_huxley(l_mtcs,tot_bridge_nr,states,calculated_muscle_forces,mtc_vels,STIM,lCEs,lSEs,K_CE_list,K_SE_list,coords_vals,s_vals,t_vals,save_name,specific_save_name=False,saveornot=True):
    state_names = [[]]*(tot_bridge_nr*2+2)
    for i in range(tot_bridge_nr):
        state_names[i]='x'+str(i)
        state_names[i+tot_bridge_nr]='n'+str(i+tot_bridge_nr)
    state_names[-2]='lce'
    state_names[-1]='activation'
    huxley_data_full = xr.Dataset(
        data_vars=dict(
            #states=(['mtc_nr','time','bridge_variable'], states),
            Fce_mtc=(['mtc_nr','time'],calculated_muscle_forces[:,:,0]),
            Fse_mtc=(['mtc_nr','time'],calculated_muscle_forces[:,:,1]),
            F_mtc=(['mtc_nr','time'],calculated_muscle_forces[:,:,2]),
            v_mtc=(['mtc_nr','time'],mtc_vels),
            l_mtc=(['mtc_nr','time'],l_mtcs),
            STIM=(['mtc_nr','time'],STIM),
            lCE=(['mtc_nr','time'],lCEs),
            lSE=(['mtc_nr','time'],lSEs),
            #lmtc=(['mtc_nr','time'],coords_vals[:,2,:]),
            KSE=(['mtc_nr','time'],K_SE_list),
            KCE=(['mtc_nr','time'],K_CE_list),
            coord=(['time','coord_type','coord_nr'],coords_vals[:,:,1:]),
            angle_values=(['time','s_item'],s_vals)
            
        ),
        coords=dict(
            #muscle=(["1", "2","3", "4","5", "6"], range(muscle_number)),
            #muscle=(['mtc_nr'], [1,2,3,4,5,6]),

            time=(t_vals)#,
            #coord_type=(['x','y','lmtc']),
            #coord_nr=(range(5)),
            #s_item=(['a1','a2','a3','a1d','a2d','a3d',])

        ),
        attrs=dict(description="States over time"),
    )
    #df_3d = states_set.to_dataframe()
    #print(df_3d)
    #import time
    #print(huxley_data_full)
    if specific_save_name != False:
        huxley_data_full.to_netcdf('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_2a/Results/data/'+str(save_name)+'__'+str(specific_save_name))
    if specific_save_name == False:
        huxley_data_full.to_netcdf('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_2a/Results/data/'+str(save_name)+'huxley_data_full_'+time.ctime())


def save_hill(l_mtcs,calculated_muscle_forces,force_vector,v_mtcs,STIM,lCEs,vCEs,t_vals,s_vals,save_name,specific_save_name=False,saveornot=True):
    
    hill_data_full = xr.Dataset(
        data_vars=dict(
            F_mtc=(['mtc_nr','time'],force_vector[:,:,0]),
            v_mtc=(['mtc_nr','time'],v_mtcs),
            l_mtc=(['mtc_nr','time'],l_mtcs),
            STIM=(['mtc_nr','time'],STIM),
            lCE=(['mtc_nr','time'],lCEs),
            vCE=(['mtc_nr','time'],vCEs),
            angle_values=(['time','s_item'],s_vals),
            F_CE=(['mtc_nr','time'],force_vector[:,:,1]),
            F_SE=(['mtc_nr','time'],force_vector[:,:,2]),
            F_PE=(['mtc_nr','time'],force_vector[:,:,3]),
            FL=(['mtc_nr','time'],force_vector[:,:,4]),
            vmax=(['mtc_nr','time'],force_vector[:,:,5]),
            FV=(['mtc_nr','time'],force_vector[:,:,6]),
            vce=(['mtc_nr','time'],force_vector[:,:,7]),
            f_rel=(['mtc_nr','time'],force_vector[:,:,8])
            
        ),
        coords=dict(
            time=(t_vals)#
        ),
        attrs=dict(description="States over time"),
    )
    #print(hill_data_full)
    if specific_save_name != False:
        hill_data_full.to_netcdf('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_2a/Results/data/'+str(save_name)+'__'+str(specific_save_name))
    if specific_save_name == False:
        hill_data_full.to_netcdf('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_2a/Results/data/'+str(save_name)+'hill_data_full_'+time.ctime())

    #testdata = xarray.open_dataset('Results/data/data_full_Sun Nov 27 22:43:30 2022_')
    #testdata.time()
    #return 'data saved succesfully.'