#The basis for this code has been provided by Dr. Jason Moore, for the TU Delft course of Multibody Dynamics 2020-2021
from general_functions import * 

#function that updates the force and generalise coordinate vectors
def F_M_vars_calc(l1, l2,l3,l4,m1, m2, J1, J2,F_mtc1,F_mtc2,F_mtc3,F_mtc4,F_mtc5,F_mtc6,r1,r2,t,alpha1,alpha2,x0,x1,x2,x3,x4,y0,y1,y2,y3,y4,p,r,J3,m3,alpha3,B1,B2,thetar1,thetar2,PE_sh1,PE_sh2,PE_xm1,PE_xm2,T_max1,T_max2,f_type=False):
    M_newton = sm.diag(J1, m1, m1,J2,m2,m2)
    
    #passive torques (Stroeve)
    T_1_shoulder = -B1*alpha1.diff(t)-sm.sign(alpha1-thetar1)*T_max1*(sm.exp(PE_sh1*sm.Abs(alpha1-thetar1)/PE_xm1)-1)/(sm.exp(PE_sh1)-1)
    
    #forces, defined in the same direction as positive
    #in this version, the direction of the forces on the body is always the same
    #add forces to system in the form of moment arm, positive moment is against the clock
    
    #no gravity case
    if f_type == 'f_damped_0grav':
        F_newton = sm.Matrix([-1*(-F_mtc1+F_mtc2)*r1+T_1_shoulder,0,0,0,0,0])
    if f_type == 'f_undamped_0grav':
        F_newton = sm.Matrix([-1*(-F_mtc1+F_mtc2)*r1,0,0,0,0,0])
    #full gravity in each limb
    if f_type == 'f_damped_fullgrav':
        F_newton = sm.Matrix([-1*(-F_mtc1+F_mtc2)*r1+T_1_shoulder,0,-m1*9.81,0,0,-m2*9.81])
    if f_type == 'f_undamped_fullgrav':
        F_newton = sm.Matrix([-1*(-F_mtc1+F_mtc2)*r1,0,-m1*9.81,0,0,-m2*9.81])
    #partial gravity or only m2
    if f_type == 'f_damped_pgrav':
        F_newton = sm.Matrix([-1*(-F_mtc1+F_mtc2)*r1+T_1_shoulder,0,0,0,0,-m2*9.81])
    if f_type == 'f_undamped_pgrav':
        F_newton = sm.Matrix([-1*(-F_mtc1+F_mtc2)*r1,0,0,0,0,-m2*9.81])
    
    #Set up a common function argument structure for all numerical functions we will use:
    p_args = (l1, l2,l3,l4,m1, m2, J1, J2,r1,r2,m3,J3,B1,B2,thetar1,thetar2,PE_sh1,PE_sh2,PE_xm1,PE_xm2,T_max1,T_max2)          # constants
    r_args = (F_mtc1,F_mtc2)  # specifieds
    q_args = (alpha1,alpha2)                              # coordinates
    qd_args = (alpha1.diff(t),alpha2.diff(t))             # speeds
    return F_newton, M_newton, q_args, qd_args, p_args, r_args 

#functions that performs the neccesary linear algebra 
def matrices_func(M_newton, F_newton, q_args, qd_args, p_args, r_args,T_mat,x,q,t):
    #convective terms
    g_conv = x.diff(t, 2).xreplace({qddi: 0 for qddi in q.diff(t, 2)})
    #reduced mass matrix
    M_tmt = T_mat.transpose()*M_newton*T_mat
    M_tmt = sm.trigsimp(M_tmt)
    #add the reduced forcing terms
    Q_tmt = T_mat.transpose()*(F_newton - M_newton*g_conv)
    #Q_tmt = sm.simplify(Q_tmt) #This step takes very long, do not repeat
    #add constraint column
    C = sm.Matrix([
        0,
        0,
    ])
    Cdd = C.diff(t, 2)
    #extract the terms to augment the mass matrix 
    C_M = Cdd.jacobian(q.diff(t, 2))
    C_Q = -Cdd.xreplace({qdd: 0 for qdd in q.diff(t, 2)})
    #form the constraint augmented mass matrix
    A = M_tmt.row_join(C_M.transpose()).col_join(C_M.row_join(sm.zeros(2, 2)))
    #add the constraint augmented forcing terms
    b = Q_tmt.col_join(C_Q)
    #Create functions that numerically evaluate  A  and  b :
    eval_A = sm.lambdify((q_args, qd_args, p_args, r_args), M_tmt)
    eval_b = sm.lambdify((q_args, qd_args, p_args, r_args), Q_tmt)
    #define jacobian of constraints
    Cq = C.jacobian(q)
    Cd = C.diff(t)
    #evaluate the constrains, its time derivative and the jacobian
    eval_C = sm.lambdify((q_args, qd_args, p_args, r_args), C)  # shape(2,1)
    eval_Cd = sm.lambdify((q_args, qd_args, p_args, r_args), Cd)  # shape(2,1)
    eval_Cq = sm.lambdify((q_args, qd_args, p_args, r_args), Cq)  # shape(2,3)
    return M_tmt, Q_tmt, C_M, C_Q, A, b, eval_A, eval_b, eval_C, eval_Cd, eval_Cq,g_conv

#function that evaluates the right hand side of the first order DAE's
def eval_rhs(t, s, p, r, eval_A, eval_b):
    """Return the derivatives of the generalized coordinates and speeds plus the Lagrange multipliers
    at a specific time with a provided set of constants.
    
    Parameters
    ==========
    t : float
        Value of time at this instant in seconds.
    s : array_like, shape(4,)
        Generalized coordinate and speed values in order [alpha1, alpha2, alpha1', alpha2'] at time t.
    p : array_like, shape(14,)
        Constant values in order [l1, l2, l3,l4,m1,J1,m2,J2,r1,r2,m3,J3,B1,B2,thetar1,thetar2,PE_sh1,PE_sh2,PE_xm1,PE_xm2,T_max1,T_max2].
    r : array_like, shape(2,)
        Specified values of time in order [F_mtc1,F_mtc2]

    Returns
    =======
    sdot : ndarray, shape(4,)
        Time derivatives of the generalized coordinates and speeds at time t in order [alpha1', alpha2',
        alpha1'', alpha2''].
    lam : ndarray, shape(2,)
        Lagrange multipliers [constraint @ D, constraint @ E].

    """
    alpha1_dot = s[2]
    alpha2_dot = s[3]
    
    # evaluate the equation of motion matrices
    A = eval_A(s[:2], s[2:], p, r)  # shape(5, 5)
    b = eval_b(s[:2], s[2:], p, r).squeeze() #  shape(5,)

    # solve the linear system to get the accelerations and Lagrange multipliers
    x = np.linalg.solve(A, b)
    q_dot = x[:2]
    lam = x[2:]
    
    alpha1_ddot = x[0]
    alpha2_ddot = x[1]
    
    # package the derivatives into a NumPy array in the correct order
    qddot = np.array([alpha1_dot,alpha2_dot,alpha1_ddot,alpha2_ddot])
    return qddot, lam




