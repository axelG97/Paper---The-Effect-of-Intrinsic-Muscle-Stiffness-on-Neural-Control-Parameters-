from general_functions import * 
from muscle_functions import *
from matrices_functions import *

def muscle_vals_func():
    #define more constants
    C1, C2, Fmax, lCEopt, s_mtc, K_SE, K_PE, K_CE, F_CEopt, width, t_act, t_deact, l_seslack, l_peslack, o_a_SE, o_a_PE, o_b_SE, o_b_PE, l_min, l_max, h_mtc_og = sm.symbols('C_1, C_2, F_max, l_(CE_(opt)), s_mtc, K_SE, K_PE, K_CE, F_(CE_(opt)), width, t_act, t_deact, l_(se_(slack)), l_(pe_(slack)), o_(a_(SE)), o_(a_(PE)), o_(b_(SE)), o_(b_(PE)), l_(min), l_(max),h_mtc_og')
    h_mtc, f1, g1, g2, g3 = sm.symbols('h_mtc, f_1, g_1, g_2, g_3')
    l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl  = sm.symbols('l_r,l_t,L_opt,L_sh,V_er,V_ml,V_vm,V_sh,V_shl') #Stroeve hill extra constants
    SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin = sm.symbols('SE_sh,PE_sh,SE_Ftoe,SE_xm,PE_xm,A,epstoe,klin') #thelen stiffness extra constants
    '''
    h_mtc: 1,#1E-8,
    f1: 80,      
    g1: 10,      
    g2: 350,  
    g3: 160, 
    '''
    muscle_pars_1 = {
        h_mtc: 1, #2.8418E-008,
        f1: 275.8722,      
        g1: 176.6001,      
        g2: 1065.6713,  
        g3: 305.0962, 
        C1: 1, #arbitrary
        C2: 1, #arbitrary
        Fmax: 1, #arbitrary
        lCEopt: 0.1, 
        s_mtc: 2.6E-6,
        K_SE: 1, #arbitrary
        K_PE: 1, #arbitrary
        K_CE: 1,#arbitrary
        F_CEopt: 1, 
        width: 0,#0.56, 
        t_act: 40, #ms 
        t_deact: 70, #ms
        l_seslack: 0.2, #*l_ceopt,
        l_peslack: 1/(1.05), #*l_ceopt, 
        o_a_SE: 0.04, 
        o_a_PE: 0.1, 
        o_b_SE: 0.5, 
        o_b_PE: 0.6, 
        l_r: 4,#0.15, #muscle rest length (m)
        l_t: 1,#0.02, #tendon length (m)
        L_opt: 0.7, #
        L_sh: 0.6, #
        V_er: 0.5, #
        V_ml: 1.3,#1.3, #
        V_vm: 6, #*lce0, nog doen
        V_sh: 0.3,#0.3, #
        V_shl: 0.23, #
        l_min: 0.21789,#0.1, #minimum muscle length
        l_max: 0.42210,#0.8, #maximum muscle length 

        #Thelen stiffness parameters from here
        SE_sh: 3,
        PE_sh: 5,
        SE_Ftoe: 0.33,
        SE_xm: 0.06,
        PE_xm: 0.6,   
        A: 0,
        epstoe: 0,
        klin: 0,
        h_mtc_og: 2.8418E-008,
        
    }
    #lce0 = lmin + L_opt*(lmax - lmin) - l_t #optimal ce length
    #lcesh = L_sh*(lmax - lmin) #width of gaussian FL curve
    muscle_pars_2 = {
        h_mtc: 1, #2.8418E-008,
        f1: 275.8722,      
        g1: 176.6001,      
        g2: 1065.6713,  
        g3: 305.0962, 
        C1: 1, #arbitrary
        C2: 1, #arbitrary
        Fmax: 1, #arbitrary
        lCEopt: 0.1, 
        s_mtc: 2.6E-6,
        K_SE: 1, #arbitrary
        K_PE: 1, #arbitrary
        K_CE: 1,#arbitrary
        F_CEopt: 1, 
        width: 0,#0.56, 
        t_act: 40, #ms 
        t_deact: 70, #ms
        l_seslack: 0.2, #*l_ceopt,
        l_peslack: 1/(1.05), #*l_ceopt, 
        o_a_SE: 0.04, 
        o_a_PE: 0.1, 
        o_b_SE: 0.5, 
        o_b_PE: 0.6, 
        l_r: 0.35,#0.15, #muscle rest length (m)
        l_t: 1,#0.02, #tendon length (m)
        L_opt: 0.7, #
        L_sh: 0.6, #
        V_er: 0.5, #
        V_ml: 1.3,#1.3, #
        V_vm: 6, #*lce0, nog doen
        V_sh: 0.3,#0.3, #
        V_shl: 0.23, #
        l_min: 0.21789,#0.1, #minimum muscle length
        l_max: 0.42210,#0.8, #maximum muscle length 

        #Thelen stiffness parameters from here
        SE_sh: 3,
        PE_sh: 5,
        SE_Ftoe: 0.33,
        SE_xm: 0.06,
        PE_xm: 0.6,   
        A: 0,
        epstoe: 0,
        klin: 0,
        h_mtc_og: 2.8418E-008,
    }
    mus_vals = []
    mus_vals.append(np.array(list(muscle_pars_1.values())))
    mus_vals.append(np.array(list(muscle_pars_2.values())))
    return mus_vals

def constant_altering_function(mus_vals,current_muscle_start_lengths,states, muscle_number,tot_bridge_nr,model_type,hill_type,Fmax_muscles=False,specific_save_name=False,experiment_name=False):
    for i in range(muscle_number):

        if Fmax_muscles != False:
            if (model_type != 'hill') or (hill_type != 'thijs'):#hardcoding the fmax scaling, except for the thijs model
                mus_vals[i][7] = Fmax_muscles
        mus_vals[i][15]  = mus_vals[i][15]*0.001#*steps_per_second #activation constants from ms to step
        mus_vals[i][16]  = mus_vals[i][16]*0.001#*steps_per_second
        mus_vals[i][8]   = 0.28#current_muscle_start_lengths[i]/5 # change to vary depending on initial muscle length
        if 'stiff_start_mostpos' in experiment_name:
            mus_vals[i][8]   = 0.29284
        if 'stiff_start_verypos' in experiment_name:
            mus_vals[i][8]   = 0.28
        if 'stiff_start_newpos' in experiment_name:
            mus_vals[i][8]   = 0.26716
        if 'stiff_start_newneg' in experiment_name:
            mus_vals[i][8]   = 0.25432
        if 'stiff_start_mostneg' in experiment_name:
            mus_vals[i][8]   = 0.24148
        if 'stiff_start_extraneg' in experiment_name:
            mus_vals[i][8]   = 0.22864
        
        if model_type == 'huuuuxley':
            states[i][0][-2] = current_muscle_start_lengths[i]*4/5.0 #lCEopt is slightly smaller than the initial lCE
            states[i][0][-1] = 0
        #mus_vals[i][14]  *= mus_vals[i][8] 
        mus_vals[i][14]  *= current_muscle_start_lengths[i]
        
        #slack lengths
        mus_vals[i][17]  *= mus_vals[i][8]
        mus_vals[i][18]  *= mus_vals[i][8]   
        
        #FL variables
        mus_vals[i][19]  *= current_muscle_start_lengths[i]
        mus_vals[i][20]  *= current_muscle_start_lengths[i]
        mus_vals[i][21]  *= current_muscle_start_lengths[i]
        mus_vals[i][22]  *= current_muscle_start_lengths[i]
        
        
        mus_vals[i][24]  *= mus_vals[i][17]*1.07 #set tendon length
        mus_vals[i][29]  *= mus_vals[i][8]#V_vm
        
        #Thelen early calc variables
        mus_vals[i][39] = mus_vals[i][36]*mus_vals[i][34]*np.exp(mus_vals[i][34])-mus_vals[i][36]*np.exp(mus_vals[i][34])+mus_vals[i][36]+np.exp(mus_vals[i][34])-1; #A
        mus_vals[i][40] = mus_vals[i][36]*mus_vals[i][34]*np.exp(mus_vals[i][34])*mus_vals[i][37]/mus_vals[i][39];#epstoe
        mus_vals[i][41] = mus_vals[i][39]/(mus_vals[i][37]*(np.exp(mus_vals[i][34])-1));#klin
  
        #set up model-specific variables
        if model_type == 'hill':
            SE0 = SEforce2length(mus_vals[i][7],mus_vals[i])
            states[i][0][0] = current_muscle_start_lengths[i]-SE0#initial length
        if model_type == 'huxley':
            states[i][0][0:tot_bridge_nr] = np.linspace(-mus_vals[i][0]*4, mus_vals[i][0]*6,tot_bridge_nr)
            for j in range(tot_bridge_nr):
                #set up initial conditions for x and n, all from the same distribution
                #states[i][0][j] = random.uniform(-mus_vals[i][0]*15, mus_vals[i][0]*15) #make initial x distribution random
                states[i][0][j+tot_bridge_nr] = n0_calc(states[i][0][j],mus_vals[i])
            xx = states[i][0][:tot_bridge_nr]
            nlimited = states[i][0][tot_bridge_nr:tot_bridge_nr*2]
            nlimited[xx>4*mus_vals[i][0]] = 0
            nlimited[xx<-2*mus_vals[i][0]] = 0 
            intx0n0 = np.trapz(xx*nlimited)
            SE0 = SEforce2length(mus_vals[i][7],mus_vals[i])#force/4 in Vardy
            states[i][0][-2] = current_muscle_start_lengths[i]-SE0#initial length
            mus_vals[i][6] = mus_vals[i][7]/intx0n0#/4 in Vardy
    return mus_vals,states