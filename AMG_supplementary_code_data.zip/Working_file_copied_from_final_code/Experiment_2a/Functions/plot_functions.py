from general_functions import * 
from muscle_functions import *
from matrices_functions import *

def plot_huxley_full(t_vals, s_vals, coords_vals,mtc_vels,calculated_huxley_force,states,activation,t0,tf,h_step,muscle_number,tot_bridge_nr,step_nr,mus_vals,p,K_SE_list,K_CE_list,save=True,save_name=False,specific_save_name=False):
    plt.close("all")
    #calculated_huxley_force = calculated_muscle_forces[:][:][2]
    #%%time
    #plt.rcParams["figure.figsize"] = (8, 6)
    muscle_color_list   =['salmon','turquoise','darkblue','lime','magenta','gold']
    br_list = [(0.1,0.0,1.0),(0.2,0.0,0.9),(0.3,0.0,0.8),(0.4,0.0,0.7),(0.5,0.0,0.6),(0.6,0.0,0.5),(0.7,0.0,0.4),(0.8,0.0,0.3),(0.9,0.0,0.2),(1.0,0.0,0.1)]#color = [(0.3,0.3,0.5)]

    #muscle_color_list_2 =['salmon','lime','slateblue']
    fig, axes = plt.subplots(5,3,figsize=(20,25));
    fig.suptitle(str(h_step)+' steps,old v,old f,FLhill,fmax1: '+str(mus_vals[0][7])+',thelen, m2: '+str(p[6])+', J2: '+str(p[7]));
    axes[0][0].grid(visible=True);
    for i in range(muscle_number):
        axes[0][0].plot(t_vals[:], activation[i],muscle_color_list[i]);
    #for i in range(muscle_number):    
    #    axes[0][0].plot(t_vals, states[i][:,-1],muscle_color_list[i]);
    axes[0][0].set_title("Activation over time")#"Activation over time, Winters, "+ 
    axes[0][0].set_ylabel('activation [-]')
    axes[0][0].set_xlabel("Time [s]");
    axes[0][0].legend(['MTC_1','MTC_2'])
    #commented on 25/09/23
    '''
    axes[1][0].grid(visible=True);
    for i in range(tot_bridge_nr):
        axes[1][0].plot(t_vals, states[0][:,i]/mus_vals[0][0]);
    axes[1][0].set_title("x of all "+str(tot_bridge_nr)+" cross-bridges in mtc1")
    axes[1][0].set_ylabel('x [h]')
    axes[1][0].set_xlabel("Time [s]")
    axes[2][0].grid(visible=True);
    for i in range(tot_bridge_nr):
        axes[2][0].plot(t_vals, states[0][:,i+tot_bridge_nr]);
    axes[2][0].set_title("n of all "+str(tot_bridge_nr)+" cross-bridges in mtc1")
    axes[2][0].set_ylabel('n')
    axes[2][0].set_xlabel("Time [s]")
    axes[2][0].set_ylim([0,1])
    
    '''
    axes[3][0].grid(visible=True);
    axes[3][0].plot(t_vals, states[0][:,-2]);
    axes[3][0].set_title("l_ce of all "+str(tot_bridge_nr)+" cross-bridges in mtc1")
    axes[3][0].set_ylabel('l [m]')
    axes[3][0].set_xlabel("Time [s]")
    axes[4][0].grid(visible=True);
    for i in range(muscle_number):
        axes[4][0].plot(t_vals[1:], K_CE_list[i][1:],muscle_color_list[i]);
    axes[4][0].set_title("CE stiffness over time")
    axes[4][0].set_ylabel('K_CE [N/m]')
    axes[4][0].set_xlabel("t [s]")
    axes[4][0].legend(['MTC_1','MTC_2'])
    axes[4][1].grid(visible=True);
    for i in range(muscle_number):
        axes[4][1].plot(t_vals[1:], K_SE_list[i][1:],muscle_color_list[i]);
    axes[4][1].set_title("SE stiffness over time")
    axes[4][1].set_ylabel('K_SE [N/m]')
    axes[4][1].set_xlabel("t [s]")
    axes[4][1].legend(['MTC_1','MTC_2'])
    '''
    axes[4][0].grid(visible=True);
    for i in range(tot_bridge_nr):
        axes[4][0].plot(states[0][:,i]/mus_vals[0][0], states[0][:,i+tot_bridge_nr]);
    axes[4][0].set_title("n(x) of all "+str(tot_bridge_nr)+" cross-bridges in mtc1")
    axes[4][0].set_ylabel('n [-]')
    axes[4][0].set_xlabel("x [h]")
    axes[4][0].set_ylim([0,1])
    '''
    axes[0][1].grid(visible=True);
    for i in range(muscle_number):
        axes[0][1].plot(t_vals, calculated_huxley_force[i],muscle_color_list[i]);
    axes[0][1].set_ylabel('Muscle force [N]')
    axes[0][1].set_xlabel("Time [s]")
    axes[0][1].set_title("Muscle Forces")
    axes[0][1].legend(['MTC_1','MTC_2'])
    states[0][:,0]
    
    #commented on 25/09/23
    '''
    axes[1][1].grid(visible=True);
    for i in range(tot_bridge_nr):
        axes[1][1].plot(t_vals, states[1][:,i]/mus_vals[0][0]);
    axes[1][1].set_title("x of all "+str(tot_bridge_nr)+" cross-bridges in mtc2")
    axes[1][1].set_ylabel('x [h]')
    axes[1][1].set_xlabel("Time [s]")
    axes[2][1].grid(visible=True);
    for i in range(tot_bridge_nr):
        axes[2][1].plot(t_vals, states[1][:,i+tot_bridge_nr]);
    axes[2][1].set_title("n of all "+str(tot_bridge_nr)+" cross-bridges in mtc2")
    axes[2][1].set_ylabel('n')
    axes[2][1].set_xlabel("Time [s]");
    axes[2][1].set_ylim([0,1])
    axes[3][1].grid(visible=True);
    axes[3][1].plot(t_vals, states[1][:,-2]);
    axes[3][1].set_title("l_ce of all "+str(tot_bridge_nr)+" cross-bridges in mtc2")
    axes[3][1].set_ylabel('l [m]')
    axes[3][1].set_xlabel("Time [s]")
    '''
    '''
    axes[4][1].grid(visible=True);
    for i in range(tot_bridge_nr):
        axes[4][1].plot(states[1][:,i]/mus_vals[0][0], states[1][:,i+tot_bridge_nr]);
    axes[4][1].set_title("n(x) of all "+str(tot_bridge_nr)+" cross-bridges in mtc2")
    axes[4][1].set_ylabel('n [-]')
    axes[4][1].set_xlabel("x [h]")
    axes[4][1].set_ylim([0,1])
    '''
    axes[0][2].grid(visible=True);
    axes[0][2].plot(t_vals, coords_vals[:,0]);
    axes[0][2].set_ylabel('x points [m]')
    axes[0][2].set_xlabel("Time [s]")
    axes[0][2].set_title("Structure movement in x-t")
    axes[0][2].legend(['x0','x1','x2'])
    #axes[1][2].set_title(str(h_step)+' stepsize,old v,old f,FLhills,fmax100, thelen')
    axes[1][2].grid(visible=True);
    axes[1][2].plot(t_vals, coords_vals[:,1]);
    axes[1][2].set_ylabel('y points [m]')
    axes[1][2].set_xlabel("Time [s]")
    axes[1][2].set_title("Structure movement in y-t")
    axes[1][2].legend(['x0','x1','x2'])
    

    axes[2][2].grid(visible=True);
    for i in range(muscle_number):
        axes[2][2].plot(t_vals, coords_vals[:,2,i],muscle_color_list[i]);
    axes[2][2].set_ylabel('muscle length [m]')
    axes[2][2].set_xlabel("Time [s]")
    axes[2][2].set_title("Muscle lengths")
    axes[2][2].legend(['MTC_1','MTC_2'])
    

    axes[3][2].grid(visible=True)
    for i in range(muscle_number):
        axes[3][2].plot(t_vals, mtc_vels[i],muscle_color_list[i]);
    axes[3][2].set_ylabel('muscle velocity [m/s]')
    axes[3][2].set_xlabel("Time [s]")
    axes[3][2].set_title("Muscle velocities")
    axes[3][2].legend(['MTC_1','MTC_2'])
    
    if save == True:
        if specific_save_name != False:
            fig.savefig('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_2a/Results/full_plot_'+str(save_name)+'__'+str(specific_save_name)+'.png');
        if specific_save_name == False:
            fig.savefig('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_2a/Results/full_plot_'+str(save_name)+'_'+time.ctime());
    plt.show();
    return 

def plot_hill_full(t_vals, s_vals, coords_vals,mtc_vels,calculated_huxley_force,states,activation,t0,tf,h_step,muscle_number,tot_bridge_nr,step_nr,mus_vals,save=True,save_name=False,specific_save_name=False):
    plt.close("all")
    #calculated_huxley_force = calculated_muscle_forces[:][:][2]
    #%%time
    #plt.rcParams["figure.figsize"] = (8, 6)
    muscle_color_list   =['salmon','turquoise','darkblue','lime','magenta','gold']
    br_list = [(0.1,0.0,1.0),(0.2,0.0,0.9),(0.3,0.0,0.8),(0.4,0.0,0.7),(0.5,0.0,0.6),(0.6,0.0,0.5),(0.7,0.0,0.4),(0.8,0.0,0.3),(0.9,0.0,0.2),(1.0,0.0,0.1)]#color = [(0.3,0.3,0.5)]

    #muscle_color_list_2 =['salmon','lime','slateblue']
    fig, axes = plt.subplots(2,3,figsize=(18,12));
    #fig.suptitle(str(p)+str(r)+str(muscle_pars_1)+'t0: '+str(t0)+', tf: '+str(tf)+', h: '+str(h_step))
    axes[0][0].grid(visible=True);
    for i in range(muscle_number):
        axes[0][0].plot(t_vals[:], activation[i],muscle_color_list[i]);
    #for i in range(muscle_number):    
    #    axes[0][0].plot(t_vals, states[i][:,-1],muscle_color_list[i]);
    axes[0][0].set_title("Activation over time")
    axes[0][0].set_ylabel('activation [-]')
    axes[0][0].set_xlabel("Time [s]");
    axes[0][0].legend(['MTC_1','MTC_2'])
    
    axes[0][1].grid(visible=True);
    for i in range(muscle_number):
        axes[0][1].plot(t_vals, calculated_huxley_force[i],muscle_color_list[i]);
    axes[0][1].set_ylabel('Muscle force [N]')
    axes[0][1].set_xlabel("Time [s]")
    axes[0][1].set_title("Muscle Forces")
    axes[0][1].legend(['MTC_1','MTC_2'])
    
    axes[0][2].grid(visible=True);
    axes[0][2].plot(t_vals, coords_vals[:,0]);
    axes[0][2].set_ylabel('x points [m]')
    axes[0][2].set_xlabel("Time [s]")
    axes[0][2].set_title("Structure movement in x-t")
    axes[0][2].legend(['x0','x1','x2'])
    
    axes[1][0].grid(visible=True);
    axes[1][0].plot(t_vals, coords_vals[:,1]);
    axes[1][0].set_ylabel('y points [m]')
    axes[1][0].set_xlabel("Time [s]")
    axes[1][0].set_title("Structure movement in y-t")
    axes[1][0].legend(['x0','x1','x2'])
    axes[1][1].grid(visible=True);
    for i in range(muscle_number):
        axes[1][1].plot(t_vals, coords_vals[:,2,i],muscle_color_list[i]);
    axes[1][1].set_ylabel('muscle length [m]')
    axes[1][1].set_xlabel("Time [s]")
    axes[1][1].set_title("Muscle lengths")
    axes[1][1].legend(['MTC_1','MTC_2'])
    axes[1][2].grid(visible=True)
    for i in range(muscle_number):
        axes[1][2].plot(t_vals, mtc_vels[i],muscle_color_list[i]);
    axes[1][2].set_ylabel('muscle velocity [m/s]')
    axes[1][2].set_xlabel("Time [s]")
    axes[1][2].set_title("Muscle velocities")
    axes[1][2].legend(['MTC_1','MTC_2'])
    
    if save == True:
        if specific_save_name != False:
            fig.savefig('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_2a/Results/full_plot_'+str(save_name)+'__'+str(specific_save_name)+'.png');
        if specific_save_name == False:
            fig.savefig('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_2a/Results/full_plot_'+str(save_name)+'_'+time.ctime());
        #fig.savefig('Results/full_model2_'+time.ctime()+'_.png')
    #plt.show();
    return 

def plot_movement_static(t_vals, s_vals, coords_vals,mtc_vels,calculated_huxley_force,states,activation,t0,tf,h_step,muscle_number,tot_bridge_nr,step_nr,mus_vals,save=True,save_name=False,specific_save_name=False):
    plt.close("all")
    muscle_color_list   =['salmon','turquoise','darkblue','lime','magenta','gold']
    br_list = [(0.1,0.0,1.0),(0.2,0.0,0.9),(0.3,0.0,0.8),(0.4,0.0,0.7),(0.5,0.0,0.6),(0.6,0.0,0.5),(0.7,0.0,0.4),(0.8,0.0,0.3),(0.9,0.0,0.2),(1.0,0.0,0.1)]
    fig, axes = plt.subplots(1,1,figsize=(10,10));
    axes.grid(visible=True);
    axes.plot(coords_vals[-1,0,0],coords_vals[-1,1,0],'go');
    for i in range(2):
        axes.plot(coords_vals[:,0,i], coords_vals[:,1,i],muscle_color_list[i+1],linestyle='dashed',linewidth=2,alpha=0.8);
    axes.plot(coords_vals[0,0,2:],coords_vals[0,1,2:],'bo');
    axes.plot(coords_vals[-1,0,2:],coords_vals[-1,1,2:],'ro');
    axes.plot(coords_vals[0,0,0:],coords_vals[0,1,0:],'b',linewidth=4);
    axes.plot(coords_vals[-1,0,0:],coords_vals[-1,1,0:],'r',linewidth=4);

    axes.set_ylabel('y points [m]')
    axes.set_xlabel("x points [m]")
    #axes.set_xlim(-0.35,0.35)
    axes.set_title("Structure movement in x-y")
    axes.legend(['x0','x1 movement','x2 movement','x3 movement','x4 movement','start position','end position'])
    for i in range(len(br_list)):
        axes.plot(coords_vals[int(len(coords_vals[:,0,0:])*i/11),0,0:],coords_vals[int(len(coords_vals[:,0,0:])*i/11),1,0:],marker='.',color = br_list[i],alpha=0.4,linewidth=3);
        #axes.plot(coords_vals[int(len(coords_vals[:,0,0:])*i/11),0,0:],coords_vals[int(len(coords_vals[:,0,0:])*i/11),1,0:],color = br_list[i],alpha=0.3,linewidth=3)
    if save == True:
        if specific_save_name != False:
            fig.savefig('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_2a/Results/move_plot_'+str(save_name)+'__'+str(specific_save_name)+'.png');
        if specific_save_name == False:
            fig.savefig('drive/My Drive/TU/Master/MEP/Paper/Working_file_copied_from_final_code/Experiment_2a/Results/move_plot_'+str(save_name)+'_'+time.ctime());
    return
